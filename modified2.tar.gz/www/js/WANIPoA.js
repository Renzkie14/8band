/*************************
 *      ��ʼ������       *
 *************************/
 function IPoA_CreateProtocol(){
 	var str=Ggeneral_ProtocolStr(mode);	
	 var addstr=str.ProtocolSelStr+str.NatStr+str.StaticStr+str.IPv4StaticDNSStr+str.GIPv6AddressStr+str.GIPv6PrefixStr+str.GIPv6DNSAdressStr;
	 jQuery("#IPv4andIPv6SEL").append(addstr); 
	 RouteProtocolSwitch();
	 staticIPv4DNSSwitch();
	 ipv6AddrSwitch();
	 ipv6PDSwitch();
	 ipv6DNSAddrSwitch();
 }
 function setIPoAdata(obj){
 	
 }
 function IPoA_init(){
 		setDisplay("MTUSize",1);
 		setDisplay("DIV_IPv4&6",1);
		IPoA_CreateProtocol();
		setValue("Static_IPv4_DNS_Enable",1);
		document.getElementById("Static_IPv4_DNS_Enable").disabled=true;
		if("edit" == pagecmd){
			var WANInfoObj=GWANInfoObj();
			setCommendata(WANInfoObj);
			setRouteProtocol(WANInfoObj);
			setIPoAdata(WANInfoObj);
  	}
  	staticIPv4DNSSwitch();
  	setLanPort();
 }
 /*************************
  *       �ύ����        *
  *************************/
  function IPoASubmit(df,WANindex){
	   var conn_path="";
	   
	    if("create" == pagecmd){
		    conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANIPConnection.";
	  		AddElements(df, 'add_obj', conn_path);
	  	  conn_path+="{i}.";
		  }else if("edit" == pagecmd){
		  	conn_path=WANPath;
		  }else{
		  		alert("pagecmd is wrong,pagecmd="+pagecmd);	
		  }
	   
	   if(!CommonSubmit(df,conn_path,pagecmd)){
	   		return false;
     }
     if(!routeProtocol_submit(df,conn_path)){
     	  return false;
     }
     return true;
  }