
function LAN_init(step)
{
    var preStepID = 'ID_DIV_setup' + (step - 1); //ǰ1����ID
    var stepID = 'ID_DIV_setup' + step;

    var setLanDefVal = function ()
    {
        setValue("INPUT_IPAddress","192.168.1.1");
        setValue("INPUT_SubAddress","255.255.255.0");
        setValue("INPUT_DNSServers1","192.168.1.1");
        setValue("INPUT_DNSServers2","");
        setValue("INPUT_DomainName","localhost");
        
        setValue("INPUT_DHCPEnable",1);
        setValue("INPUT_MinAddress","192.168.1.2");
        setValue("INPUT_MaxAddress","192.168.1.254");
    }
    
    var LanStr='<br/>'
        +'<table width="600" cellpadding="0" cellspacing="0" class="ContentTableNoColor">'
            +'<tr>'
                +'<td>'
                    +getStr("LK_ConfigureLAN")
                +'</td>'
            +'</tr>'
        +'</table>'
        +'<br />'
        +'<table cellpadding="0" width="600" cellspacing="0" class="ContentTableNoColor">'
        +'<tr>'
            +'<td width="150">'+getStr("LK_IPAddresss")+'</td>'
            +'<td><input type="text" maxlength=15 name="INPUT_IPAddress" id="INPUT_IPAddress" onChange="IPandDNS1(this.value);" /></td>'
        +'</tr>'
        +'<tr>'
            +'<td>'+getStr("LK_SubnetMaskk")+'</td>'
            +'<td><input type="text" maxlength=15 name="INPUT_SubAddress" id="INPUT_SubAddress" value=""></td>'
        +'</tr>'
        +'<tr>'
            +'<td>'+getStr("LK_PrimaryDNSServer")+'</td>'
            +'<td><input type="text" maxlength=15 name="INPUT_DNSServers1" id="INPUT_DNSServers1" value=""></td>'
        +'</tr>'
        +'<tr>'
            +'<td>'+getStr("LK_SecondaryDNSServer")+'</td>'
            +'<td><input type="text" maxlength=15 name="INPUT_DNSServers2" id="INPUT_DNSServers2" value=""></td>'
        +'</tr>'
       +' <tr>'
            +'<td>'+getStr("LK_DomainNamee") +'</td>'
            +'<td><input type="text" maxlength=64 name="INPUT_DomainName" id="INPUT_DomainName" value=""></td>'
       +' </tr>'
       +' <tr>'
            +'<td>'+getStr("LK_net_dhcpserverenable") + ':' +'</td>'
            +'<td><input type="checkbox"  name="INPUT_DHCPEnable" id="INPUT_DHCPEnable" onClick="switch_LAN_DHCP(this.id);" /></td>'
       +' </tr>'
        +'<tr class="css_DHCP_Ena">'
            +'<td>'+getStr("LK_StartPCc")+'</td>'
            +'<td><input type="text" maxlength=15 name="INPUT_MinAddress" id="INPUT_MinAddress" ></td>'
        +'</tr>'
        +'<tr class="css_DHCP_Ena">'
            +'<td>'+getStr("LK_EndPCc")+'</td>'
            +'<td><input type="text" maxlength=15 name="INPUT_MaxAddress" class="control" id="INPUT_MaxAddress" ></td>'
        +'</tr>' 

        +'</table>'    
    +'<br/>';

    /* ����ǵ�1���������ID_DIV_labstep���棬�������ǰһ������ */
    if(step == 1)
    {
        jQuery("#ID_DIV_labstep").after('<div id="' + stepID +  '" style="display:none"></div>');
    }
    else
    {
        jQuery("#" + preStepID).after('<div id="' + stepID +  '" style="display:none"></div>');
    }

    addHTML(stepID, LanStr);

    setLanDefVal();
    switch_LAN_DHCP("INPUT_DHCPEnable");

    /* �洢check�����������Next��ʱ������ */
    gCheckFuncArray.push(LAN_CheckAll);

    gSubmitFuncArray.push(LAN_Submit);
}

function IPandDNS1(value)
{
    var node = $('INPUT_IPAddress', 'INPUT_MinAddress','INPUT_MaxAddress','INPUT_DNSServers1');
    node[3].value=node[0].value; //�Զ�����dns
    var firName = node[0].value.split('.');
    var fir=firName[0]+"."+firName[1]+"."+firName[2];//�����û������IP, ��ȡ����
    var MinIP= node[1].value.split('.').slice(-1); //��ȡ�ɵ�ַ�ص���ʼ��ַ
    var MaxIP= node[2].value.split('.').slice(-1);//��ȡ�ɵ�ַ�صĽ�����ַ
    node[1].value = fir +"." + MinIP;
    node[2].value = fir +"." + MaxIP;
} 

function switch_LAN_DHCP(ID)
{
     var hiddenStyle="position:absolute;visibility:hidden";
    if( 0 == getValue(ID))
        setStyle("css_DHCP_Ena",hiddenStyle);
    else
        setStyle("css_DHCP_Ena","");
}

function LAN_CheckAll()
{
    if(!isCheckIPV4($('INPUT_IPAddress'),1,254)){            
          return false;
    }
    if(!isCheckIPV4($('INPUT_SubAddress'))){            
          return false;
    }
    if(!isCheckIPV4($('INPUT_DNSServers1'))){            
        return false;
    }
    if($('INPUT_DNSServers2').value != "" && !isCheckIPV4($('INPUT_DNSServers2'))){            
        return false;
    }    
    if(0 != getValue("INPUT_DHCPEnable"))
    {
        if(!isCheckIPV4($('INPUT_MinAddress'),1,254)){            
          return false;
        }
        if(!isCheckIPV4($('INPUT_MaxAddress'))){            
          return false;
        }
    }
    return true;
}

function LAN_Submit()
{
    var lan_str=getValue("INPUT_IPAddress");
    lan_str+="?"+getValue("INPUT_SubAddress");
    lan_str+="?"+getValue("INPUT_DNSServers1");
    lan_str+="?"+getValue("INPUT_DNSServers2");
    lan_str+="?"+getValue("INPUT_DomainName");
    lan_str+="?"+getValue("INPUT_DHCPEnable");
    lan_str+="?"+getValue("INPUT_MinAddress");
    lan_str+="?"+getValue("INPUT_MaxAddress");

    script_action('lan?'+ lan_str);
}