document.write('<script language="javascript" src="/js/tri.js"></script>');
document.write('<script language="javascript" src="/js/jquery.js"></script>');
document.write('<script language="javascript" src="/js/init.js"></script>');
document.write('<script language="javascript" src="/js/t_utils.js"></script>');
document.write('<script language="javascript" src="/js/ajax.js"></script>');
document.write('<script language="javascript" src="/js/sha256.js"></script>');
document.write('<script language="javascript" src="/js/check.js"></script>');


function setHTML(ID,str)
{

    if("<TBODY></TBODY>" == document.getElementById(ID).innerHTML)
    {
        jQuery("#"+ID).empty();
        jQuery("#"+ID).append(str);
    }
    else
        document.getElementById(ID).innerHTML=str;   
    
}

function addHTML(ID,str)
{
  
    jQuery("#"+ID).append(str);
}

function setStyle(CLASSNAME,cssStr) 
{ 
    var elements = new Array();
    if(!document.getElementsByClassName)
    { 
        var children = document.getElementsByTagName('tr'); 
        for (var i=0; i < children.length; i++)
        { 
            var classNames = children[i].className.split(' '); 
            for (var j = 0; j < classNames.length; j++)
            { 
                if (classNames[j] == CLASSNAME)
                { 
                    elements.push(children[i]); 
                    break;
                } 
            } 
        }      
    }
    else
    {
        elements = document.getElementsByClassName(CLASSNAME);
    }

    for(var i = 0;i < elements.length ; i++)
    {
       // elements[i].setAttribute("style",cssStr);//������IE�Ĳ��������
        elements[i].style.cssText = cssStr;         //����IE���������google
    }

}

function tranform(pwd)
{
    var i;
    var dst="";
    for(i=0;i<pwd.length;i+=2)
    {
        var tmp = (parseInt(pwd[i] + pwd[i+1],16));
        dst += String.fromCharCode(tmp);
    }
    return dst;
}

function qst_getStr(ID,LANKEY)
{
    if(LANKEY == "") return LANKEY;
    var vars = 'window.parent.parent.' + LANKEY;  
    setHTML(ID,eval(vars));
}
