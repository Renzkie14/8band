function WANIface_init(step)
{
    var arrayMode = new Array(); /* ATM/PTM/ETH1/Dongle */
    var preStepID = 'ID_DIV_setup' + (step - 1); //前1步的ID
    var stepID = 'ID_DIV_setup' + step;

    var WANIfacelStr='<br/>'
        +'<table width="600" cellpadding="0" cellspacing="0" class="ContentTableNoColor">'
            +'<tr>'
                +'<td>'
                    +getStr("LK_ConfigureWANIface")
                +'</td>'
            +'</tr>'
        +'</table>'
        +'<br />'
        +'<table width="600" cellpadding="0" cellspacing="0" class="ContentTableNoColor">'
            +'<tr>'
                +'<td width="100px">'+getStr("LK_WAN_Interface")+'</td>'
                +'<td>'
                    +'<select id="ID_SELECT_WAN_mode" onChange="switchWAN_mode(this)">'
                    +'</select>'
                +'</td>'
            +'</tr>'
            +' <tr  class = "css_ATM">'
                +'<td width="100px">'+getStr("LK_Encapsulationn")+'</td>'
                +'<td>'
                    +'<select id = "ID_SELECT_ATMENC">'
                        +'<option  value="LLC" selected >LLC</option>'
                        +'<option  value="VCMUX">VCMUX</option>'
                    +'</select>'
                +'</td>'
            +'</tr>'
            +' <tr  class = "css_ATM">'
                +'<td width="100px">'+getStr("LK_VPI_VCI")+'</td>'
                +'<td>'
                        +'<input style="width:40px" id = "ID_INPUT_vpi" type = "text"   />/'
                        +'<input style="width:40px" id = "ID_INPUT_vci" type = "text"  />'
                +'</td>'
            +'</tr>'
        +'</table>'
        +'<br/>';

    /* 如果是第1步，则加在ID_DIV_labstep后面，否则加在前一步后面 */
    if(step == 1)
    {
        jQuery("#ID_DIV_labstep").after('<div id="' + stepID +  '" style="display:none"></div>');
    }
    else
    {
        jQuery("#" + preStepID).after('<div id="' + stepID +  '" style="display:none"></div>');
    }
    addHTML(stepID, WANIfacelStr);

    /* 根据WAND的配置生成模式下拉框 */
    for(var i=0; i<gEnabledWANDArray.length; i++)
    {
        if(gEnabledWANDArray[i].WANDSLInterfaceConfigEnable == '1')
        {
        	if(-1 != gDSLSuport.indexOf("ATM"))
                arrayMode.push('ATM');
            if(-1 != gDSLSuport.indexOf("PTM"))
            	arrayMode.push('PTM');
        }

        if(gEnabledWANDArray[i].WANEthernetInterfaceConfigEnable == "1")
            arrayMode.push('ETH1');//用ETH1，后续可以支持多ETH上行

        if(gEnabledWANDArray[i].WANDongleInterfaceConfigEnable == "1")
            arrayMode.push('Dongle');
    }
    createOptions('ID_SELECT_WAN_mode', arrayMode, arrayMode);

    /* 初始化WAN模式 */
    switchWAN_mode(document.getElementById("ID_SELECT_WAN_mode"));

    /* 存储check函数，当点击Next的时候会调用 */
    gCheckFuncArray.push(WANIface_CheckAll);
}   


function switchWAN_mode(obj)
{
    var hiddenStyle="position:absolute;visibility:hidden";

    switch(obj.value)
    {
        case "ATM":
            setStyle("css_PTM",hiddenStyle);
            setStyle("css_ETH",hiddenStyle);
            setStyle("css_ATM","");
            break;    
        case "PTM":
            setStyle("css_ATM",hiddenStyle);
            setStyle("css_ETH",hiddenStyle);
            setStyle("css_PTM","");
            break;
        case "ETH1":
            setStyle("css_ATM",hiddenStyle);
            setStyle("css_PTM",hiddenStyle);
            setStyle("css_ETH","");
            break;
        case "Dongle":
            setStyle("css_ATM",hiddenStyle);
            setStyle("css_PTM",hiddenStyle);
            setStyle("css_ETH",hiddenStyle);
            break;
    }

    SwitchVlan();//函数定义在QST_WANServiceConf.js中，因为setStyle之后，VLAN ID的输入框被显示出来，所以需要两次隐藏
}




function checkPVC(vpiID,vciID)
{
     var vpi = getValue(vpiID);
     var vci = getValue(vciID);

     var patrn=/^([0-9]\d*)$/;
     if (!patrn.exec(vpi) || !patrn.exec(vci))
     {
         top.AlertMsg(getStr("LK_naturaNum"));
         return false;
     }
     else
     {
             if (vpi<0 || vpi >255 ) 
             {
                 top.AlertMsg(getStr("LK_VPI"),vpiID);
                 return false;
             }
             if (vci<32 || vci >65535)
             {
                 top.AlertMsg(getStr("LK_VCI"),vciID);
                 return false;
             }
    }   
    return true;
}


function WANIface_CheckAll()
{

    if("ATM" == getValue("ID_SELECT_WAN_mode"))
    {
        if(!checkPVC("ID_INPUT_vpi","ID_INPUT_vci"))
            return false;
    }

    return true;
}