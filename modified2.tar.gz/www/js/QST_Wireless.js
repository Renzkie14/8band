
function Wireless_init(step)
{
    var preStepID = 'ID_DIV_setup' + (step - 1); //前1步的ID
    var stepID = 'ID_DIV_setup' + step;

    var setWirelessVal = function ()
    {

        if(gWifiRadioEnable2G == "1"){
            setValue("ID_INPUT_Wireless24g",1);
            setValue("ID_INPUT_Wireless24gSSID",gWlanArray[0].SSID);
            setValue("ID_INPUT_Wireless24gPassphrase",tranform(gWlanArray[0].PreSharedKey1PreSharedKey));
        }
        
        if(gWifiRadioEnable5G == "1"){
         	setValue("ID_INPUT_Wireless5g",1);
            setValue("ID_INPUT_Wireless5gSSID",gWlanArray[4].SSID);
            setValue("ID_INPUT_Wireless5gPassphrase",tranform(gWlanArray[4].PreSharedKey1PreSharedKey));
        }
    }

    var WirelessStr='<br/>'
        +'<table width="600" cellpadding="0" cellspacing="0" class="ContentTableNoColor">'
            +'<tr>'
                +'<td>'
                    +getStr("LK_ConfigureWLAN")
                +'</td>'
            +'</tr>'
        +'</table>'
        +'<br />'
         +'<table id="ID_DIV_WirelessInfo" cellpadding="0" cellspacing="0" width="350" class="ContentTableNoColor">';
    if(gWifiRadioEnable2G == "1"){
        WirelessStr+='<tr>'
            +'<td>'+getStr("LK_Enablee")+'</td>'
            +'<td><input id ="ID_INPUT_Wireless24g" type="checkbox" ></td>'
        +'</tr>'
        +'<tr>'
            +'<td>'+getStr("LK_SSID24gg")+'</td>'
            +'<td><input id="ID_INPUT_Wireless24gSSID" type="text" ></td>'
        +'</tr>'        
        +'<tr>'
            +'<td>'+getStr("LK_WPA24gg")+'</td>'
            +'<td><input id="ID_INPUT_Wireless24gPassphrase" type="text"  ></td>'
        +'</tr>';
    }
             
    if(gWifiRadioEnable5G == "1"){
    	WirelessStr+= '<tr>'
                 +'<td>'+getStr("LK_Enablee")+'</td>'
                 +'<td><input id ="ID_INPUT_Wireless5g" type="checkbox"></td>'
             +'</tr>'
             +'<tr>'
                 +'<td>'+getStr("LK_SSID5gg")+'</td>'
                 +'<td><input id="ID_INPUT_Wireless5gSSID" type="text"></td>'
             +'</tr>'
             +'<tr>'
                 +'<td>'+getStr("LK_WPA5gg")+'</td>'
                 +'<td><input id="ID_INPUT_Wireless5gPassphrase" type="text" ></td>'
             +'</tr>';
     
    }
    WirelessStr+='</table>'    
               +'<br/>';
    
    /* 如果是第1步，则加在ID_DIV_labstep后面，否则加在前一步后面 */
    if(step == 1)
    {
        jQuery("#ID_DIV_labstep").after('<div id="' + stepID +  '" style="display:none"></div>');
    }
    else
    {
        jQuery("#" + preStepID).after('<div id="' + stepID +  '" style="display:none"></div>');
    }

    addHTML(stepID, WirelessStr);

    setWirelessVal();

    /* 存储check函数，当点击Next的时候会调用 */
    gCheckFuncArray.push(Wireless_CheckAll);

    gSubmitFuncArray.push(Wireless_Submit);
}


function Wireless_CheckAll()
{
    var checkWirelessNamePassword = function (NameID,PassID,EnableID)
    {
        var Ena = getValue(EnableID);
        var Name = getValue(NameID);
        var PassWord = getValue(PassID);

        /* 如果无线没有使能，则直接返回，检查通过 */
        if(Ena == 0)
            return true;

        if (Name == "")
        {
            top.AlertMsg(getStr("LK_userNameEmpty"),NameID);
            return false;
        }

        if (PassWord.length < 8)
        {
            top.AlertMsg(getStr("LK_Thelengthwrong") + '8',PassID);
            return false;
        }

        return true;
    }
    if(!checkWirelessNamePassword("ID_INPUT_Wireless24gSSID","ID_INPUT_Wireless24gPassphrase","ID_INPUT_Wireless24g"))
        return false;
    if(!checkWirelessNamePassword("ID_INPUT_Wireless5gSSID","ID_INPUT_Wireless5gPassphrase","ID_INPUT_Wireless5g"))
        return false;

    return true;
}


function Wireless_Submit()
{
    var wireless_str=gWifiRadioEnable2G+"?"+gWifiRadioEnable5G;
  
    if(gWifiRadioEnable2G == "1"){
    	wireless_str+="?"+getValue("ID_INPUT_Wireless24g");
	    wireless_str+="?"+getValue("ID_INPUT_Wireless24gSSID");
	    wireless_str+="?"+change_to_hex(getValue("ID_INPUT_Wireless24gPassphrase"));
    }
    else{
    	wireless_str+="???";
    }
    
    if(gWifiRadioEnable5G == "1"){
    	wireless_str+="?"+getValue("ID_INPUT_Wireless5g");
	    wireless_str+="?"+getValue("ID_INPUT_Wireless5gSSID");
	    wireless_str+="?"+change_to_hex(getValue("ID_INPUT_Wireless5gPassphrase"));
    }else{
    	wireless_str+="???";
    }
    
    script_action('wireless?'+ wireless_str);
}