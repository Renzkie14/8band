/*************************
 *        ��������       *
 *************************/
function PPPoAConnTriggerSwitch(){
    var trigger_type = getValue('SELECT_ConnTrigger');
    setDisplay('DIV_PPPoA_OnDemand', 'OnDemand' == trigger_type ? 1 : 0);
    setDisplay('DIV_PPPoA_AlwaysOn_KeepAliveTime', 'AlwaysOn' == trigger_type ? 1 : 0);
		setDisplay('DIV_PPPoA_AlwaysOn_KeepAliveMaxFail', 'AlwaysOn' == trigger_type ? 1 : 0);
}
/*************************
 *      ��ʼ������       *
 *************************/
function PPPoA_CreateProtocol(){
	 var str=Ggeneral_ProtocolStr(mode);	
	 var addstr=str.ProtocolSelStr+str.NatStr+str.IPv4StaticDNSStr+str.GIPv6AddressStr+str.GIPv6PrefixStr+str.GIPv6DNSAdressStr;
	 jQuery("#IPv4andIPv6SEL").append(addstr); 
	 RouteProtocolSwitch();
	 staticIPv4DNSSwitch();
	 ipv6AddrSwitch();
	 ipv6PDSwitch();
	 ipv6DNSAddrSwitch();
}
function OnlyForPPPoA(nowiface){
	var PPPoAOptionStr="";
 	if(1){
 		PPPoAOptionStr='<table id="PPPoA_table" class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0">'
			+'<tr>'
			  +'<td>'+getStr("LK_UserNamee")+'</td>'
				+'<td><input type="text" id="INPUT_UserName"></td>'
			+'</tr>'
			+'<tr>'
				+'<td>'+getStr("LK_Passwordd")+'</td>'
				+'<td><input type="password" id="INPUT_Password" value="**************" onChange="Password_changed()"></td>'
			+'</tr>'
			+'<tr>'
			  +'<td>'+getStr("LK_AuthTypee")+'</td>'
			  +'<td><select id="SELECT_AuthType">'
		      +'<option value="Auto">'+getStr("LK_AUTO")+'</option>'
		      +'<option value="PAP">PAP</option>'
		      +'<option value="CHAP">CHAP</option>'
	      +'</select>'
			  +'</td>'
		  +'</tr>'
		  +'<tr>'
			  +'<td>'+getStr("LK_DialModee")+'</td>'
			  +'<td><select id="SELECT_ConnTrigger" onChange="PPPoAConnTriggerSwitch()">'
			  	  +'<option value="AlwaysOn">'+getStr("LK_Automatically")+'</option>'
		        +'<option id="OnDemand" value="OnDemand">'+getStr("LK_DialonDemand")+'</option>'
			+'<option id="Manual" value="Manual">'+getStr("LK_ManualConnect")+'</option>'
			  	+'</select>'
	      +'</td>'
		  +'</tr>'
		  +'<tr id="DIV_PPPoA_AlwaysOn_KeepAliveTime">'
				+'<td width="150">'+getStr("LK_KeepAliveTimee")+'</td>'
			  +'<td><input type="text" name="INPUT_KeepAliveTime" id="INPUT_KeepAliveTime" value="30"> (10-30)s</td>'
			+'</tr>'
			+'<tr id="DIV_PPPoA_AlwaysOn_KeepAliveMaxFail">'
				+'<td width="150">'+getStr("LK_KeepAliveMaxFaile")+'</td>'
				+'<td><input type="text" name="INPUT_KeepAliveMaxFail" id="INPUT_KeepAliveMaxFail" value="5"> (1-100)</td>'
			+'</tr>'
		  +'<tr id="DIV_PPPoA_OnDemand">'
			  +'<td>'+getStr("LK_IdleTimeoutt")+'</td>'
			  +'<td><input type="text" id="INPUT_IdleDisconnectTime">(60~65535)s</td>'
		  +'</tr>'
		 	+'<tr>'
			  +'<td width="150">'+getStr("LK_LimitRetryTimee")+'</td>'
			  +'<td><input type="checkbox" name="INPUT_LimitRetryTimeEnable" id="INPUT_LimitRetryTimeEnable" onClick="LimitRetryTimeEnable()">'+getStr("LK_LimitRetryTimeText")+'</td>'
	    +'</tr>'
	    +'<tr id="DIV_RetryTime">'
			  +'<td width="150">'+getStr("LK_RetryTimee")+'</td>'
			  +'<td><input type="text" name="INPUT_RetryTime" id="INPUT_RetryTime" value="3"> (0-100)</td>'
		  +'</tr>'
   +'</table>';
  }
  jQuery("#DIV_PPPoA").append(PPPoAOptionStr);	
  LimitRetryTimeEnable();
  PPPoAConnTriggerSwitch();
}
function setPPPoAdata(obj){
	setValue('INPUT_UserName',obj.Username);
	setValue('SELECT_AuthType',obj.X_TRI_PPPAuthenticationProtocol);
	setValue('SELECT_ConnTrigger',obj.ConnectionTrigger);
	setValue('INPUT_KeepAliveTime',obj.PPPLCPEcho);
	setValue('INPUT_KeepAliveMaxFail',obj.PPPLCPEchoRetry);     
	setValue('INPUT_IdleDisconnectTime',obj.IdleDisconnectionTime);
	setValue('INPUT_LimitRetryTimeEnable',obj.X_TRI_LimitRetryTime);
	setValue('INPUT_RetryTime',obj.X_TRI_RetryTimes);	
	LimitRetryTimeEnable();  
	PPPoAConnTriggerSwitch();
}
function PPPoA_init(){
	setDisplay("MTUSize",1);
	setDisplay("DIV_IPv4&6",1);
	setDisplay("DIV_PPPoA",1);
	PPPoA_CreateProtocol();
	OnlyForPPPoA(iface);
	if("edit" == pagecmd){
		var WANInfoObj=GWANInfoObj();
		setCommendata(WANInfoObj);
		setRouteProtocol(WANInfoObj);
		setPPPoAdata(WANInfoObj);
  }
  setLanPort();
}
 /*************************
 *       �ύ����        *
 *************************/
function pppoaconnection_process(df, conn_instance_path){    
		var username = getValue('INPUT_UserName');
		var ip_version = getValue('SELECT_Protocol');
		var ConnTrigger=getValue('SELECT_ConnTrigger');
    if (isValidStr(username) != true){
    		top.AlertMsg(getStr("LK_namenoinc")+"\\ and \'");
        return false;
    }

    AddElements(df, conn_instance_path + 'ConnectionType', 'IP_Routed');
    AddElements(df, conn_instance_path + 'X_CT-COM_ProxyEnable', 0);
 
    AddElements(df, conn_instance_path + 'ConnectionTrigger',ConnTrigger);   	
    AddElements(df, conn_instance_path + 'Username', username);
    if(password_changed == 1){
       var password = getValue('INPUT_Password');
       if (isValidStr(password) != true){
            top.AlertMsg(getStr("LK_passerror")+"\\ and \'");
            return false;
       }
       AddElements(df, conn_instance_path + 'Password',password);
    }
    AddElements(df, conn_instance_path + 'X_TRI_PPPAuthenticationProtocol', getValue('SELECT_AuthType'));
    if ('OnDemand' == ConnTrigger){
       AddElements(df, conn_instance_path + 'IdleDisconnectTime', getValue('INPUT_IdleDisconnectTime'));
    }else if ('AlwaysOn' == ConnTrigger){
         AddElements(df, conn_instance_path + 'PPPLCPEcho', getValue('INPUT_KeepAliveTime'));
         AddElements(df, conn_instance_path + 'PPPLCPEchoRetry', getValue('INPUT_KeepAliveMaxFail'));
    }
    AddElements(df, conn_instance_path + 'X_TRI_LimitRetryTime', getValue('INPUT_LimitRetryTimeEnable'));
    if (getValue('INPUT_LimitRetryTimeEnable') == '1'){
         AddElements(df, conn_instance_path + 'X_TRI_RetryTimes', getValue('INPUT_RetryTime'));
    }

    AddElements(df, conn_instance_path + 'MACAddressOverride','0');
    return true;
}
function PPPoASubmit(df,WANindex){
	 var conn_path="";
   if("create" == pagecmd){
	    conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANPPPConnection.";
  		AddElements(df, 'add_obj', conn_path);
  	  conn_path+="{i}.";
   }else if("edit" == pagecmd){
   		conn_path=WANPath;
   }else{
   		alert("pagecmd is wrong,pagecmd="+pagecmd);	
   }
   
   if(!CommonSubmit(df,conn_path,pagecmd)){
   		return false;
   }
   if(!routeProtocol_submit(df,conn_path)){
   		return false;	
   }
	 if(!pppoaconnection_process(df,conn_path)){
   		return false;	
   }
   return true;	
}
