/*************************
 *      ��ʼ������       *
 *************************/
function Con_Bridged_init(){
  setDisplay("MTUSize",0);
  setDisplay("TR_VlanPassThnEnable",1);
  if("edit" == pagecmd){
  	var WANInfoObj=GWANInfoObj();
  	setCommendata(WANInfoObj);
  }
  setLanPort();
}
/*************************
 *       �ύ����        *
 *************************/
function CoNBriSubmit(df,WANindex){
	 var conn_path="";
	 if("create" == pagecmd){
	   conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANIPConnection.";
     AddElements(df, 'add_obj', conn_path);
     conn_path+="{i}.";
   }else if("edit" == pagecmd){
   		conn_path=WANPath;
   }else{
   		alert("pagecmd is wrong,pagecmd="+pagecmd);	
   }
   
   if(!CommonSubmit(df,conn_path,pagecmd)){
   		return false;
   }
   AddElements(df,conn_path+'NATEnabled','1');
   AddElements(df,conn_path+"X_TRI_DhcpTransparent", 1);
   return true;
}