/*************************
 *      ��ʼ������       *
 *************************/
function Bridge_CreateProtocol(){
	 var str=Ggeneral_ProtocolStr(mode);	
	 jQuery("#IPv4andIPv6SEL").append(str.ProtocolSelStr); 
}
function Bridge_init(){
	setDisplay("MTUSize",0);
	setDisplay("DIV_IPv4&6",1);
  setDisplay("TR_VlanPassThnEnable",1);
	Bridge_CreateProtocol();
	if("edit" == pagecmd){
  	var WANInfoObj=GWANInfoObj();
  	setCommendata(WANInfoObj);
  	setValue('SELECT_Protocol',WANInfoObj.IPMode);
  }
  setLanPort();
}
/*************************
 *       �ύ����        *
 *************************/
function BridgeSubmit(df,WANindex){
	 var conn_path="";
	 if("create" == pagecmd){
		 conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANIPConnection.";
	   AddElements(df, 'add_obj', conn_path);
	   conn_path+="{i}.";
   }else if("edit" == pagecmd){
   		conn_path=WANPath;
   }else{
   		alert("pagecmd is wrong,pagecmd="+pagecmd);	
   }
   
   if(!CommonSubmit(df,conn_path,pagecmd)){
   		return false;
   }
   
   return true;
}