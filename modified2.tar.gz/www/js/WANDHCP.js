
/*************************
 *        ��������       *
 *************************/
function OP60SettingEnable(){
    setDisplay('DIV_OP60', getValue('INPUT_OP60SettingEnable'));
}
function clearID(){
    setValue('INPUT_OP60Setting', "");
}

function OP81SettingEnable(){
    setDisplay('DIV_OP81', getValue('INPUT_OP81SettingEnable'));
}
/*************************
 *      ��ʼ������       *
 *************************/
function OnlyForDHCP(nowiface){

	var CreatTabStr=function(){
		var forDongleStr="";
		if(nowiface.indexOf("USB") > -1){	
			  forDongleStr=onlyForDongle();
		}
		var GMACAddrOverrStr=GMACAddressOverrideStr();
		
		var DHCPOptionStr="";
		if(1){
		   DHCPOptionStr=forDongleStr
				 +'<table  id="ID_TABLE_DHCP" class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0">'
				   	 +'<tr>'
						+'<td  width="150">' +getStr("LK_EnableOP60Setting")+'</td>'
					  	+'<td><input type="checkbox" id="INPUT_OP60SettingEnable" onClick="OP60SettingEnable()"></td>'
					 +'</tr>'
					 +'<tr id="DIV_OP60">'
						+'<td >'+getStr("LK_OP60Setting")+'</td>'
						+'<td>'
							+'<input type="text" id="INPUT_OP60Setting">'
							+'<input type="button" id="op60SettingButton" onclick="clearID()" value="'+getStr("LK_OP60Clear")+'">'
						+'</td>'
					+'</tr>'
					+'<tr>'
						+'<td >'+getStr("LK_EnableOP66Setting")+':</td>'
						+'<td><input type="checkbox" id="INPUT_OP66SettingEnable"></td>'
					+'</tr>'
					+'<tr>'
						+'<td >'+getStr("LK_EnableOP120Setting")+':</td>'
						+'<td><input type="checkbox" id="INPUT_OP120SettingEnable"></td>'
					+'</tr>'
				   	 +'<tr>'
						+'<td  width="150">' +getStr("LK_EnableOP81Setting")+'</td>'
					  	+'<td><input type="checkbox" id="INPUT_OP81SettingEnable" onClick="OP81SettingEnable()"></td>'
					 +'</tr>'
					 +'<tr id="DIV_OP81">'
						+'<td >'+getStr("LK_OP81Setting")+'</td>'
						+'<td><input type="text" id="INPUT_OP81Setting"></td>'
					+'</tr>'
				+'</table>';
	  }
		return DHCPOptionStr;
	}
	jQuery("#ID_DIV_AdvAdd").append(CreatTabStr());
	jQuery("#DIV_DHCP").append(GMACAddressOverrideStr());
	
	OP60SettingEnable();
	OP81SettingEnable();
}
function DHCP_CreateProtocol(){
	 var str=Ggeneral_ProtocolStr(mode);	
	 var addstr=str.ProtocolSelStr+str.NatStr+str.IPv4StaticDNSStr+str.GIPv6AddressStr+str.GIPv6PrefixStr+str.GIPv6DNSAdressStr;
	 jQuery("#IPv4andIPv6SEL").append(addstr); 
	 RouteProtocolSwitch();
	 staticIPv4DNSSwitch();
	 ipv6AddrSwitch();
	 ipv6PDSwitch();
   ipv6DNSAddrSwitch();
}
function setDHCPdata(obj){
    setValue('INPUT_OP60SettingEnable',obj.OP60SettingEnable);
    setValue('INPUT_OP60Setting',obj.OP60Setting);
    setValue('INPUT_OP66SettingEnable',obj.OP66SettingEnable);
    setValue('INPUT_OP120SettingEnable',obj.OP120SettingEnable);
    setValue('INPUT_OP81SettingEnable',obj.OP81SettingEnable);
    setValue('INPUT_OP81Setting',obj.OP81Setting);
    OP60SettingEnable();
    OP81SettingEnable();
}
function DHCP_init(){
	setDisplay("MTUSize",1);
	setDisplay("DIV_IPv4&6",1);
	setDisplay("DIV_DHCP",1);
	DHCP_CreateProtocol();
	OnlyForDHCP(iface);
	if("edit" == pagecmd){
  	var WANInfoObj=GWANInfoObj();
  	setCommendata(WANInfoObj);
  	setMACAddressOverride(WANInfoObj);
  	setRouteProtocol(WANInfoObj);
  	setDHCPdata(WANInfoObj);
  	if(iface.indexOf("USB") > -1){
  		SetDongle(WANInfoObj);
  	}
  }
  setLanPort();
}
/*************************
 *       �ύ����        *
 *************************/
function DHCPSubmit(df,WANindex){
	 var conn_path="";
	 if("create" == pagecmd){
	    conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANIPConnection.";
  		AddElements(df, 'add_obj', conn_path);
  	  conn_path+="{i}.";
   }else if("edit" == pagecmd){
   		conn_path=WANPath;
   }else{
   		alert("pagecmd is wrong,pagecmd="+pagecmd);	
   }
   
   if(!CommonSubmit(df,conn_path,pagecmd)){
   		return false;
   }
   if(!routeProtocol_submit(df,conn_path)){
   			return false;
   }
   if(!MACAddressOverrideSubmit(df,conn_path)){
   		return false;
   }
	 if(iface.indexOf("USB") > -1){
	 		if(!DongleSubmit(df,conn_path)){
   			return false;
   		}
	 }
   AddElements(df, conn_path + 'X_TRI_OP60SettingEnable', getValue('INPUT_OP60SettingEnable'));
   AddElements(df, conn_path + 'X_TRI_OP60Setting', getValue('INPUT_OP60Setting'));
   AddElements(df, conn_path + 'X_TRI_OP66SettingEnable', getValue('INPUT_OP66SettingEnable'));
   AddElements(df, conn_path + 'X_TRI_OP120SettingEnable', getValue('INPUT_OP120SettingEnable'));
   AddElements(df, conn_path + 'X_TRI_OP81SettingEnable', getValue('INPUT_OP81SettingEnable'));
   AddElements(df, conn_path + 'X_TRI_OP81Setting', getValue('INPUT_OP81Setting'));
   return true;
}

