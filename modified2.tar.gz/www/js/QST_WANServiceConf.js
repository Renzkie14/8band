function WANService_init(step)
{
    var preStepID = 'ID_DIV_setup' + (step - 1); //前1步的ID
    var stepID = 'ID_DIV_setup' + step;

    var ProtocolStr='<br/>'
        +'<table width="600" cellpadding="0" cellspacing="0" class="ContentTableNoColor">'
            +'<tr>'
                +'<td>'
                    +getStr("LK_ConfigureWANService")
                +'</td>'
            +'</tr>'
        +'</table>'
        +'<br />'
        +'<table width="600" cellpadding="0" cellspacing="0" class="ContentTableNoColor">'
            +' <tr id="ID_TR_protocol" >'
                +'<td width="100px">'+getStr("LK_Modee")+'</td>'
                +'<td>'
                    +'<select id = "ID_SELECT_Protocol" onChange="switchProtocol(this)">'
                        +'<option  value="DHCP" selected >DHCP</option>'
                        +'<option  value="PPPoE">PPPoE</option>'
                        +'<option  value="STATIC">STATIC</option>'          
                    +'</select>'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_ppp">'
                +'<td width="100px">'+getStr("LK_Usernamee")+'</td>'
                +'<td>'
                    +'<input id="ID_INPUT_PPP_Name" type = "text" />'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_ppp">'
                +'<td width="100px">'+getStr("LK_Passwordd")+'</td>'
                +'<td>'
                    +'<input id="ID_INPUT_PPP_Password" type = "text" />'
                +'</td>'
            +'</tr>'
             +' <tr class = "css_static">'
                +'<td width="100px">'+getStr("LK_IPAddress")+'</td>'
                +'<td>'
                    +'<input id="ID_INPUT_STATIC_IPAddress" type = "text" />'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_static">'
                +'<td width="100px">'+getStr("LK_IPSubnetmaskk")+'</td>'
                +'<td>'
                    +'<input id="ID_INPUT_STATIC_IPSubnetmask" type = "text" />'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_static">'
                +'<td width="100px">'+getStr("LK_DefaultGatewayy")+'</td>'
                +'<td>'
                    +'<input id="ID_INPUT_STATIC_DefaultGateway" type = "text" />'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_static">'
                +'<td width="100px">'+getStr("LK_PrimaryDNSServer")+'</td>'
                +'<td>'
                    +'<input id="ID_INPUT_STATIC_PrimaryDNSServer" type = "text" />'
                +'</td>'
            +'</tr>'
            +' <tr >'
                +'<td width="100px">'+getStr("LK_MTUu")+'</td>'
                +'<td>'
                    +'<input  id="ID_INPUT_mtu" type = "text" style="width:100px" value="1492"/>'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_PTM css_ETH" style="display:none">'
                +'<td width="100px">'+ getStr("LK_EnableVLANn") +'</td>'
                +'<td>'
                    +'<input  name = "NAME_CHECKBOX_VLANEnable" type = "checkbox"  onClick="SwitchVlan();" />'
                +'</td>'
            +'</tr>'
            +' <tr class = "css_PTM css_ETH" id="ID_TR_VLAN" style="display:none">'
                +'<td width="100px">'+getStr("LK_VLANIDd")+'</td>'
                +'<td>'
                    +'<input  id="ID_INPUT_vid" type = "text" style="width:100px" /><span>(0~4095)</span>'
                +'</td>'
            +'</tr>'
        +'</table>'
        +'<br/>';

    /* 如果是第1步，则加在ID_DIV_labstep后面，否则加在前一步后面 */
    if(step == 1)
    {
        jQuery("#ID_DIV_labstep").after('<div id="' + stepID +  '" style="display:none"></div>');
    }
    else
    {
        jQuery("#" + preStepID).after('<div id="' + stepID +  '" style="display:none"></div>');
    }
    addHTML(stepID, ProtocolStr);

    switchProtocol(document.getElementById("ID_SELECT_Protocol"));

    /* 存储check函数，当点击Next的时候会调用 */
    gCheckFuncArray.push(WANService_CheckAll);

    gSubmitFuncArray.push(WANService_Submit);
}   



/* 显示或者隐藏VLAN输入框 */
function  SwitchVlan()
{
	/* 当第一次switchWAN_mode来调用时，为null */
	if($("NAME_CHECKBOX_VLANEnable") == null)
	    return;

    if($("NAME_CHECKBOX_VLANEnable").checked)
    {
        setDisplay("ID_TR_VLAN", true);
    }
    else
    {
        setDisplay("ID_TR_VLAN", false);
    }
}

function switchProtocol(obj)
{
     var hiddenStyle="position:absolute;visibility:hidden";
    switch(obj.value)
    {
        case "DHCP":
            setStyle("css_ppp",hiddenStyle);
            setStyle("css_static",hiddenStyle);
        break;
        case "PPPoE":
            setStyle("css_static",hiddenStyle);
            setStyle("css_ppp","");
        break;
        case "STATIC":
            setStyle("css_ppp",hiddenStyle);
            setStyle("css_static","");
        break;
        case "BRIDGE":
            setStyle("css_ppp",hiddenStyle);
            setStyle("css_static",hiddenStyle);
        break;
    }
}

function checkVLAN(ID)
{
    var targetVlan = getValue(ID);

    if(targetVlan == "")
    {
        top.AlertMsg(getStr('LK_InputVlanID'),ID);
        return false;
    }
    else if(isAllNum(targetVlan)==0)
    {
        top.AlertMsg(getStr('LK_InputNum'),ID);
        return false;
    }
    else
    {
        if(targetVlan < 1 || targetVlan > 4095)
        {
            top.AlertMsg(getStr("LK_vlaniderror"),ID);
            return false;
        }
    }

    return true;
}

function checkUserName(ID) 
{
    var UserName = getValue(ID);
    if (UserName == "") {
        top.AlertMsg(getStr("LK_NameNULL"), ID);
        return false;
    }
    return true;
}

function checkPassword(ID)
{
    var Password = getValue(ID);
    if (Password == "")
    {
        top.AlertMsg(getStr("LK_PassNULL"),ID);
        return false;
    }
    return true;
}

function checkMTU(ID)
{
    var mtu = getValue(ID);
    if("PPPoE" == getValue("ID_SELECT_Protocol"))
    {
        if (mtu < 576 || mtu > 1492)
        {
            top.AlertMsg(getStr("LK_TheRange1492"),ID);
            return false;
        }
    }
    else
    {
        if (mtu < 576 || mtu > 1500)
        {
            top.AlertMsg(getStr("LK_TheRange1500"),ID);
            return false;
        }
    }
    return true;
}

function WANService_CheckAll()
{
    if("PPPoE" == getValue("ID_SELECT_Protocol"))
    {
        if(!checkUserName("ID_INPUT_PPP_Name") || !checkPassword("ID_INPUT_PPP_Password") )
            return false;
    }
    else if("STATIC" == getValue("ID_SELECT_Protocol"))
    {
         if(!isCheckIPV4($('ID_INPUT_STATIC_IPAddress')))
            return false;
        if(!isCheckIPV4($('ID_INPUT_STATIC_IPSubnetmask')))
            return false;
        if(!isCheckIPV4($('ID_INPUT_STATIC_DefaultGateway')))
            return false;
        if(!isCheckIPV4($('ID_INPUT_STATIC_PrimaryDNSServer')))
            return false;
    }

    if(!checkMTU("ID_INPUT_mtu"))
        return false;

    if("Activated" == getValue("NAME_CHECKBOX_VLANEnable") && !checkVLAN("ID_INPUT_vid"))
        return false;

    return true;
}

function WANService_Submit()
{
    var wanMode = getValue('ID_SELECT_WAN_mode');
    var ProtocolType = getValue("ID_SELECT_Protocol");
    var wanName;
    var mtu=getValue("ID_INPUT_mtu");
    var WANDPath = "";
    var Str="";
    var vlanID = getValue("ID_INPUT_vid");

    if(wanMode=='undefined')
    {
        WANDPath = gEnabledWANDArray[0].Path;
        WANDPath = WANDPath.substr(0, WANDPath.length -1);
        switch(WANDPath)
        {
            case "InternetGatewayDevice.WANDevice.2":
                wanMode = "ETH1"
                break;
            case "InternetGatewayDevice.WANDevice.3":
                wanMode = "Dongle"
                break;
        }
    }
    else
    {
        switch(wanMode)
        {
            case "ATM":
            case "PTM":
                WANDPath = "InternetGatewayDevice.WANDevice.1"
                break;
            case "ETH1":
                WANDPath = "InternetGatewayDevice.WANDevice.2"
                break;
            case "Dongle":
                WANDPath = "InternetGatewayDevice.WANDevice.3"
                break;
        }
    }

    wanName = wanMode + "_" + getValue("ID_SELECT_Protocol");

    switch(ProtocolType)
    {
        case "DHCP":
        break;
        case "PPPoE":
            Str=getValue("ID_INPUT_PPP_Name")+","+getValue("ID_INPUT_PPP_Password");
            
        break;
        case "STATIC":
            Str=getValue('ID_INPUT_STATIC_IPAddress')+","+getValue('ID_INPUT_STATIC_IPSubnetmask')+","+getValue('ID_INPUT_STATIC_DefaultGateway')+","+getValue('ID_INPUT_STATIC_PrimaryDNSServer');
        break;
        default :
            alert("not support!");
        break
    }

    if(vlanID == "")
    {
        vlanID = '-1'
    }

    if(wanMode == 'ATM')
    {
        wanMode = 'ATM,' + getValue('ID_SELECT_ATMENC') +',PVC:' + getValue('ID_INPUT_vpi') +'/' +getValue('ID_INPUT_vci');
    }

    script_action('wan?'+WANDPath+"?"+wanMode+'?'+ProtocolType+"?"+wanName+"?"+mtu+"?"+vlanID+'?'+Str);
}

