/*************************
 *        ��������       *
 *************************/
function PPPoEConnTriggerSwitch(){
    var trigger_type = getValue('SELECT_ConnTrigger');
    setDisplay('DIV_PPPoE_OnDemand', 'OnDemand' == trigger_type ? 1 : 0);
    setDisplay('DIV_PPPoE_AlwaysOn_KeepAliveTime', 'AlwaysOn' == trigger_type ? 1 : 0);
		setDisplay('DIV_PPPoE_AlwaysOn_KeepAliveMaxFail', 'AlwaysOn' == trigger_type ? 1 : 0);
}

function PPPoETypeSwitch(){
    var pppoe_type = getValue('SELECT_PPPoeType');
    var sh = ('PPPoE_Proxy' == pppoe_type ? 1 : 0);
    setDisplay('OnDemand',!sh);
    setDisplay('Manual',!sh);
    setDisplay('DIV_PPPoE_Proxy', sh);
    if(sh){
		  setDisplay('DIV_PPPoE_AlwaysOn_KeepAliveTime',sh);
		  setDisplay('DIV_PPPoE_AlwaysOn_KeepAliveMaxFail',sh);
		  setDisplay('DIV_PPPoE_OnDemand', !sh);
    }
    if(!sh){
 	    PPPoEConnTriggerSwitch();
 	  }
}

function DualLanEnable(){
    setDisplay("DIV_DualLanCfg", getValue('INPUT_DualLanEn'));
}
/*************************
 *      ��ʼ������       *
 *************************/
 function OnlyForPPPoE(nowiface){
 	var PPPoEOptionStr="";
 	var DualLanStr="";
 	var GMACAddrOverrStr=GMACAddressOverrideStr();
 	var forDongleStr="";
 	if(nowiface.indexOf("USB") > -1){	
			  forDongleStr=onlyForDongle();
		}
 	if(1){
 			DualLanStr='<table id="DIV_DualLanCfg" style="display:none" class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0">'
   				+'<tr>'
	    				+'<td width="150">'+getStr("LK_AddrMode")+'</td>'
	    				+'<td>'
		   				+'<select id="selectaddrmode">'
            						+'<option value="1">static</option>'
		    				+'</select>'
	    				+'</td>'
    				+'</tr>'
   				+'<tr>'
	    				+'<td>'+getStr("LK_PPPoEIP")+'</td>'
	    				+'<td><input type="text" maxlength=15 id="INPUT_PPPoEIP"/></td>'
    				+'</tr>'
				+'<tr>'
						+'<td>'+getStr("LK_LanBridgeIP")+'</td>'
						+'<td><input type="text" maxlength=15 id="INPUT_UnnumLanIP"/></td>'
				+'</tr>'
				+'<tr>'
						+'<td>'+getStr("LK_LanBridgeMask")+'</td>'
						+'<td><input type="text" maxlength=15 id="INPUT_UnnumLanMask"/></td>'
				+'</tr>'
				+'<tr>'
						+'<td>'+getStr("LK_LanStartIP")+'</td>'
					  +'<td><input type="text" maxlength=15 id="INPUT_LanStartIP"/></td>'
				+'</tr>'
				+'<tr>'
						+'<td>'+getStr("LK_LanEndIP")+'</td>'
						+'<td><input type="text" maxlength=15 id="INPUT_LanEndIP"/></td>'
				+'</tr>'
				+'<tr>'
					+'<td>'+getStr("LK_LanPriDns")+'</td>'
						+'<td><input type="text" maxlength=15 id="INPUT_LanPriDns"/></td>'
				+'</tr>'
				+'<tr>'
				    +'<td>'+getStr("LK_LanSecDns")+'</td>'
					  +'<td><input type="text" maxlength=15 id="INPUT_LanSecDns"/></td>'
				+'</tr>'
				+'<tbody id="CHECK_UnnumLanPort"></tbody>'
				+'<tr>'
				    +'<td width="150">Unnum Port:</td>'
				    +'<td>'
				      	+'<input type="checkbox" id="INPUT_LanPort1_UN"> <span id="lang_lanPort1">LAN1</span>'
				      	+'<input type="checkbox" id="INPUT_LanPort2_UN"> <span id="lang_lanPort2">LAN2</span>'
				        +'<input type="checkbox" id="INPUT_LanPort3_UN"> <span id="lang_lanPort3">LAN3</span>'
					      +'<input type="checkbox" id="INPUT_LanPort4_UN"> <span id="lang_lanPort4">LAN4</span>'
					  +'</td>'
				+'</tr>'
				+'<tr>'
				     +'<td></td>'
				     +'<td>'
				      	+'<input type="checkbox" id="INPUT_WlanSsid1_UN"> <span id="lang_wlanssid1">'+ getStr("LK_SSID1")+'</span>'
				        +'<input type="checkbox" id="INPUT_WlanSsid2_UN"> <span id="lang_wlanssid2">'+ getStr("LK_SSID2")+'</span>'
				        +'<input type="checkbox" id="INPUT_WlanSsid3_UN"> <span id="lang_wlanssid3">'+ getStr("LK_SSID3")+'</span>'
				        +'<input type="checkbox" id="INPUT_WlanSsid4_UN"> <span id="lang_wlanssid4">'+ getStr("LK_SSID4")+'</span>'
				     +'</td>'
				+'</tr>'    
				+'<tr id="DIV_WLAN_EXT_UN">'
				     +'<td></td>'
				     +'<td>'
				       +'<input type="checkbox" id="INPUT_WlanSsid5_UN"> <span id="lang_wlanssid5">'+ getStr("LK_SSID5")+'</span>'
				       +'<input type="checkbox" id="INPUT_WlanSsid6_UN"> <span id="lang_wlanssid6">'+ getStr("LK_SSID6")+'</span>'
				       +'<input type="checkbox" id="INPUT_WlanSsid7_UN"> <span id="lang_wlanssid7">'+ getStr("LK_SSID7")+'</span>'
				       +'<input type="checkbox" id="INPUT_WlanSsid8_UN"> <span id="lang_wlanssid8">'+ getStr("LK_SSID8")+'</span>'
				     +'</td>'
				+'</tr>'    
				+'<tr class="FlagText">'
				      +'<td></td><td>'+ getStr("LK_UnnumLanPortHelp")+'</td>'
				+'</tr>'
		+'</table>';
 	}
 	if(1){
 		PPPoEOptionStr=forDongleStr
 		+'<table id="PPPoE_table" class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0">'
	 		+'<tr id="pppoe_type">'
			  +'<td width="150">'+getStr("LK_PPPoETypee")+'</td>'
			  +'<td><select id="SELECT_PPPoeType" onChange="PPPoETypeSwitch()">'
			  	+'<option value="IP_Routed">'+getStr("LK_NormalPPPoE")+'</option>'
			    +'<option value="PPPoE_Proxy">'+getStr("LK_PPPoEProxy")+'</option>'
			   +'</select>'
			  +'</td>'
		  +'</tr>'
	 		+'<tr id="ID_TR_ServiceName">'
				+'<td>'+getStr("LK_ServiceName")+'</td>'
				+'<td><input type="text" id="INPUT_ServiceName"></td>'
			+'</tr>'
			+'<tr id="ID_TR_UserName">'
			  +'<td>'+getStr("LK_UserNamee")+'</td>'
				+'<td><input type="text" id="INPUT_UserName"></td>'
			+'</tr>'
			+'<tr id="ID_TR_Password">'
				+'<td>'+getStr("LK_Passwordd")+'</td>'
				+'<td><input type="password" id="INPUT_Password" value="**************" onChange="Password_changed()"></td>'
			+'</tr>'
			+'<tr id="DIV_PPPoE_Proxy" style="display:none">'
			  +'<td>'+getStr("LK_MaxProxyNumm")+'</td>'
			  +'<td><input type="text" id="INPUT_MAXUser">(1~5)</td>'
		  +'</tr>'
			+'<tr id="ID_TR_AuthType">'
			  +'<td>'+getStr("LK_AuthTypee")+'</td>'
			  +'<td><select id="SELECT_AuthType">'
		      +'<option value="Auto">'+getStr("LK_AUTO")+'</option>'
		      +'<option value="PAP">PAP</option>'
		      +'<option value="CHAP">CHAP</option>'
		      +'<!--<option value="MS-CHAP">'+getStr("LK_net_MS_CHAPAuthType")+'</option>-->'
	      +'</select>'
			  +'</td>'
		  +'</tr>'
		  +'<tr id="ID_TR_DialMode">'
			  +'<td>'+getStr("LK_DialModee")+'</td>'
			  +'<td><select id="SELECT_ConnTrigger" onChange="PPPoEConnTriggerSwitch()">'
			  	  +'<option value="AlwaysOn">'+getStr("LK_Automatically")+'</option>'
		        +'<option id="OnDemand" value="OnDemand">'+getStr("LK_DialonDemand")+'</option>'
			+'<option id="Manual" value="Manual">'+getStr("LK_ManualConnect")+'</option>'
			  	+'</select>'
	      +'</td>'
		  +'</tr>'
		  +'<tr id="DIV_PPPoE_AlwaysOn_KeepAliveTime">'
				+'<td width="150">'+getStr("LK_KeepAliveTimee")+'</td>'
			  +'<td><input type="text" name="INPUT_KeepAliveTime" id="INPUT_KeepAliveTime" value="30"> (10-30)s</td>'
			+'</tr>'
			+'<tr id="DIV_PPPoE_AlwaysOn_KeepAliveMaxFail">'
				+'<td width="150">'+getStr("LK_KeepAliveMaxFaile")+'</td>'
				+'<td><input type="text" name="INPUT_KeepAliveMaxFail" id="INPUT_KeepAliveMaxFail" value="5"> (1-100)</td>'
			+'</tr>'
		  +'<tr id="DIV_PPPoE_OnDemand">'
			  +'<td>'+getStr("LK_IdleTimeoutt")+'</td>'
			  +'<td><input type="text" id="INPUT_IdleDisconnectTime">(60~65535)s</td>'
		  +'</tr>'
   +'</table>'+GMACAddrOverrStr;
  }
  
  var AdvSetTableStr='<table id="ID_TABLE_DualLan" class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0">'
			    +'<tr id="ID_TR_LimitRetryTime">'
			        +'<td width="150">'+getStr("LK_LimitRetryTimee")+'</td>'
			        +'<td><input type="checkbox" name="INPUT_LimitRetryTimeEnable" id="INPUT_LimitRetryTimeEnable" onClick="LimitRetryTimeEnable()">'+getStr("LK_LimitRetryTimeText")+'</td>'
			    +'</tr>'
			    +'<tr id="DIV_RetryTime" style="display:none" >'
			        +'<td width="150">'+getStr("LK_RetryTimee")+'</td>'
			        +'<td><input type="text" name="INPUT_RetryTime" id="INPUT_RetryTime" value="3"> (0-100)</td>'
			    +'</tr>'
			    +'<tr id="ID_TR_PPPoEPassThrough">'
				+'<td width="150">PPPoEPassThrough:</td>'
				+'<td><input type="checkbox" id="INPUT_PPPoEPassThrough" checked></td>'
			    +'</tr>'
			    +'<tr id="DIV_DualLanEn">'
	      		        +'<td width="150">Enable Dual Lan:</td>'
			        +'<td><input type="checkbox" id="INPUT_DualLanEn" onClick="DualLanEnable()" ></td>'
			    +'</tr></table>'+DualLanStr;
  jQuery("#DIV_PPPoE").append(PPPoEOptionStr);
  jQuery("#ID_DIV_AdvAdd").append(AdvSetTableStr);
  PPPoETypeSwitch();
  PPPoEConnTriggerSwitch();
  LimitRetryTimeEnable();
  DualLanEnable();
 }
 function PPPoE_CreateProtocol(){
	 var str=Ggeneral_ProtocolStr(mode);	
	 var addstr=str.ProtocolSelStr+str.NatStr+str.IPv4StaticDNSStr+str.GIPv6AddressStr+str.GIPv6PrefixStr+str.GIPv6DNSAdressStr;
	 jQuery("#IPv4andIPv6SEL").append(addstr); 
	 RouteProtocolSwitch();
	 staticIPv4DNSSwitch();
	 ipv6AddrSwitch();
	 ipv6PDSwitch();
	 ipv6DNSAddrSwitch();
 }
 function getduallanidx(path){
    for (var i = 0; i < DualLanCfgList.length; i++)
    {
      if (DualLanCfgList[i].Path == path){
          return i;
      }
    }
    return -1;
 }
 function setPPPoEdata(obj){
	 	setValue('INPUT_ServiceName',obj.ServiceName);
	 	setValue('INPUT_UserName',obj.Username);
	 	if (obj.ProxyEnable == '0'){
	  	setValue('SELECT_PPPoeType', 'IP_Routed');
	  }else if (obj.ProxyEnable == '1'){
	    setValue('SELECT_PPPoeType', 'PPPoE_Proxy');
	  }
	  setValue('INPUT_MAXUser',obj.MAXUser);
	 	setValue('INPUT_PPPoEPassThrough',obj.PPPoEPassThrough);
	 	setValue('SELECT_ConnTrigger',obj.ConnectionTrigger);
	 	setValue('SELECT_AuthType',obj.X_TRI_PPPAuthenticationProtocol);
	  setValue('INPUT_KeepAliveTime',obj.PPPLCPEcho);
	  setValue('INPUT_KeepAliveMaxFail',obj.PPPLCPEchoRetry);     
	  setValue('INPUT_IdleDisconnectTime',obj.IdleDisconnectionTime);
	  setValue('INPUT_LimitRetryTimeEnable',obj.X_TRI_LimitRetryTime);
	  setValue('INPUT_RetryTime',obj.X_TRI_RetryTimes);
	  
	  var br_path=obj.unnum_path;
    var lan_idx=getduallanidx(br_path);
    if(lan_idx != -1){ 
    	  var unnumObj=DualLanCfgList[lan_idx];
		    setValue('INPUT_DualLanEn',obj.unnum_en);
		    setValue("selectaddrmode",unnumObj.AddrMode);
		    setValue("INPUT_PPPoEIP", unnumObj.IpAddr);
		    setValue("INPUT_UnnumLanIP", unnumObj.IpUnnumberedAddr);
		    setValue("INPUT_UnnumLanMask",unnumObj.IpUnnumberedMask);
		    setValue("INPUT_LanStartIP",unnumObj.LanStartIp);
		    setValue("INPUT_LanEndIP",unnumObj.LanEndIp);
		    setValue("INPUT_LanPriDns",unnumObj.PrimaryDns );
		    setValue("INPUT_LanSecDns",unnumObj.SecondaryDns );
		
		    setValue('INPUT_LanPort1_UN', unnumObj.LanPort.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN1")+1)) > -1 ? 1 : 0);
		    setValue('INPUT_LanPort2_UN', unnumObj.LanPort.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN2")+1)) > -1 ? 1 : 0);
		    setValue('INPUT_LanPort3_UN', unnumObj.LanPort.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN3")+1)) > -1 ? 1 : 0);
		    setValue('INPUT_LanPort4_UN', unnumObj.LanPort.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN4")+1)) > -1 ? 1 : 0);
		
		    setValue('INPUT_WlanSsid1_UN',unnumObj.LanPort.indexOf('WLANConfiguration.1') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid2_UN',unnumObj.LanPort.indexOf('WLANConfiguration.2') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid3_UN',unnumObj.LanPort.indexOf('WLANConfiguration.3') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid4_UN',unnumObj.LanPort.indexOf('WLANConfiguration.4') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid5_UN',unnumObj.LanPort.indexOf('WLANConfiguration.5') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid6_UN',unnumObj.LanPort.indexOf('WLANConfiguration.6') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid7_UN',unnumObj.LanPort.indexOf('WLANConfiguration.7') > -1 ? 1 : 0);
		    setValue('INPUT_WlanSsid8_UN',unnumObj.LanPort.indexOf('WLANConfiguration.8') > -1 ? 1 : 0);
    }
	 	PPPoETypeSwitch();
	 	PPPoEConnTriggerSwitch();
		LimitRetryTimeEnable();
		DualLanEnable();
 }
 function PPPoE_init(){
 	setDisplay("MTUSize",1);
	setDisplay("DIV_IPv4&6",1);
	setDisplay("DIV_PPPoE",1);
	PPPoE_CreateProtocol();
	OnlyForPPPoE(iface);

	if("edit" == pagecmd){
	  	var WANInfoObj=GWANInfoObj();
	  	setCommendata(WANInfoObj);
	  	setMACAddressOverride(WANInfoObj);
	  	setRouteProtocol(WANInfoObj);
	  	setPPPoEdata(WANInfoObj);
		if(iface.indexOf("USB") > -1){
			SetDongle(WANInfoObj);
		}
   }
   else{
		if(iface.indexOf("USB") > -1){
			setValue("INPUT_APN",G_DONGLE_APN);
		}
   }   	
   setLanPort();
 }
 /*************************
 *       �ύ����        *
 *************************/
function pppoeconnection_process(df, conn_instance_path){    
		var username = getValue('INPUT_UserName');
		var ip_version = getValue('SELECT_Protocol');
		var conn_type=getValue("SELECT_PPPoeType");
		var ConnTrigger=getValue('SELECT_ConnTrigger');
    if (isValidStr(username) != true){
    		top.AlertMsg(getStr("LK_namenoinc")+"\\ and \'");
        return false;
    }
    if (conn_type == 'IP_Routed'){
       /* normal pppoe */
        AddElements(df, conn_instance_path + 'ConnectionType', 'IP_Routed');
        AddElements(df, conn_instance_path + 'X_CT-COM_ProxyEnable', 0);
    }else if (conn_type == 'PPPoE_Proxy'){
        AddElements(df, conn_instance_path + 'ConnectionType', 'IP_Routed');
        AddElements(df, conn_instance_path + 'X_CT-COM_ProxyEnable', 1);
        /* max proxy user numbers */
        if(checkRange(getValue('INPUT_MAXUser'),1, 1, 5) && !isNaN(getValue('INPUT_MAXUser'))){
            AddElements(df, conn_instance_path + 'X_CT-COM_MAXUser', getValue('INPUT_MAXUser'));
        }else{
            top.AlertMsg(getStr("LK_pppoemaxuser"),'INPUT_MAXUser');
             return false;
        }
    }
    AddElements(df, conn_instance_path + 'ConnectionTrigger',ConnTrigger);
    AddElements(df, conn_instance_path + 'PPPoEServiceName', getValue('INPUT_ServiceName'));    
    AddElements(df, conn_instance_path + 'X_TRI_PPPoEPassThrough', getValue('INPUT_PPPoEPassThrough'));		
    AddElements(df, conn_instance_path + 'Username', username);
    if(password_changed == 1){
       var password = getValue('INPUT_Password');
       if (isValidStr(password) != true){
            top.AlertMsg(getStr("LK_passerror")+"\\ and \'");
            return false;
       }
       AddElements(df, conn_instance_path + 'Password',password);
    }
    AddElements(df, conn_instance_path + 'X_TRI_PPPAuthenticationProtocol', getValue('SELECT_AuthType'));
    if ('OnDemand' == ConnTrigger){
       AddElements(df, conn_instance_path + 'IdleDisconnectTime', getValue('INPUT_IdleDisconnectTime'));
    }else if ('AlwaysOn' == ConnTrigger){
         AddElements(df, conn_instance_path + 'PPPLCPEcho', getValue('INPUT_KeepAliveTime'));
         AddElements(df, conn_instance_path + 'PPPLCPEchoRetry', getValue('INPUT_KeepAliveMaxFail'));
    }
    // reset manual action when submit
    AddElements(df, conn_instance_path + 'X_TRI_ManualConnect', 0);

    AddElements(df, conn_instance_path + 'X_TRI_LimitRetryTime', getValue('INPUT_LimitRetryTimeEnable'));
    if (getValue('INPUT_LimitRetryTimeEnable') == '1'){
         AddElements(df, conn_instance_path + 'X_TRI_RetryTimes', getValue('INPUT_RetryTime'));
    }
    return true;
}
function getDualLanPort(){
    // check unnum port, MUST be subset of bound ports
    var wanbindport=getBindingports();
    var dport;
    var bport;

    /* the selected lan port and ssid */
    var dual_ports = '';

    //LAN
    for (var i = 1; i < 5; i++){
    	  var LanNum = getIndexByDescription("LAN"+i) + 1;
        dport = 'INPUT_LanPort' + i + '_UN';
        bport = 'LANEthernetInterfaceConfig.' + LanNum;

        if(dport && getValue(dport) == 1){
        	  if(-1 < wanbindport.indexOf(bport)){
            	  dual_ports += 'InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.' + LanNum + ',';
            }else{
                top.AlertMsg("Unnumbered Lan port " + bport + " doesn't bind to this Wan connection");
            }
        }
    }

    //SSID
    for (var i = 1; i < 9; i++){
        dport = 'INPUT_WlanSsid' + i + '_UN';
        bport = 'WLANConfiguration.' + i;

        if (dport && getValue(dport) == 1){
            if( wanbindport.indexOf(bport) > -1 ){
                dual_ports += 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.' + i + ',';
            }else{
                top.AlertMsg("Unnumbered SSID " + bport + " doesn't bind to this Wan connection");
            }
        }
    }

    /* delete the first and last comma */
    dual_ports = dual_ports.replace(/(^,*)|(,*$)/g,'');
    return dual_ports;
}
function Duallancfgsubmit(df, wanpath){
    var en= getValue('INPUT_DualLanEn');
    var duallist_path;
    var br_idx;
    var brnameid=DualLanCfgList.length+1;
    var brname = "bripunnum"+brnameid;

    AddElements(df, wanpath + 'X_TRI_UnnumberEn', en);
    if(en==1){
      if(!isCheckIPV4($('INPUT_PPPoEIP'))
		    || !isCheckIPV4($('INPUT_UnnumLanIP'))
    		|| !isIPMaskValid(getValue('INPUT_UnnumLanMask'))
	    	|| !isCheckIPV4($('INPUT_LanStartIP'))
		    || !isCheckIPV4($('INPUT_LanEndIP'))){   
            top.AlertMsg("Wrong ip and mask.");
            return false;
      }    
    	if(getValue('selectaddrmode') == "2"){
          top.AlertMsg("DHCP NOT supported now.");
          return false;
      }

      if("create" == pagecmd){
      	 duallist_path="InternetGatewayDevice.Layer2Bridging.Bridge.{i}"; 
         AddElements(df, 'add_obj',duallist_path);
         AddElements(df, duallist_path+".BridgeName", brname);
         AddElements(df,wanpath + 'X_TRI_UnnumberLanPath',"InternetGatewayDevice.Layer2Bridging.Bridge."+brnameid+".");
      }else if("edit" == pagecmd){
      	 var WANInfoObj=GWANInfoObj();
         if("" == WANInfoObj.unnum_path){
	         	duallist_path="InternetGatewayDevice.Layer2Bridging.Bridge.{i}"; 
	          AddElements(df, 'add_obj',duallist_path);
	          AddElements(df, duallist_path+".BridgeName", brname);
	          AddElements(df, wanpath + 'X_TRI_UnnumberLanPath', "InternetGatewayDevice.Layer2Bridging.Bridge."+brnameid +".");
         }else{
         		duallist_path=WANInfoObj.unnum_path;
            // remove the tailing '.'
            duallist_path=duallist_path.replace(/(.$)/g,'');	
         }
      }
       // update
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.Enable", '1');
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.AddrMode", getValue('selectaddrmode'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.IpAddr", getValue('INPUT_PPPoEIP'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.IpUnnumberedAddr", getValue('INPUT_UnnumLanIP'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.IpUnnumberedMask", getValue('INPUT_UnnumLanMask'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.LanStartIp", getValue('INPUT_LanStartIP'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.LanEndIp", getValue('INPUT_LanEndIP'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.PrimaryDns", getValue('INPUT_LanPriDns'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.SecondaryDns", getValue('INPUT_LanSecDns'));
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.LanPort", getDualLanPort());
      AddElements(df, duallist_path+".X_TRI_DualLanCfg.WanConnPath", wanpath);
    }
    return true;
}
function PPPoESubmit(df,WANindex){
	
	 var conn_path="";
   if("create" == pagecmd){
	    conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANPPPConnection.";
  		AddElements(df, 'add_obj', conn_path);
  	  conn_path+="{i}.";
   }else if("edit" == pagecmd){
   		conn_path=WANPath;
   }else{
   		alert("pagecmd is wrong,pagecmd="+pagecmd);	
   }

   if(!CommonSubmit(df,conn_path,pagecmd)){
   		return false;
   }
	 if(!routeProtocol_submit(df,conn_path)){
	 		return false;	
	 }
	 if(!MACAddressOverrideSubmit(df,conn_path)){
	 		return false;
	 }
	 
	 if(iface.indexOf("USB") > -1){
	 		if(!DongleSubmit(df,conn_path)){
	 			return false;	
	 		}
	 }
	 if(!pppoeconnection_process(df,conn_path)){
   		return false;	
   }
   if(!Duallancfgsubmit(df,conn_path)){
      return false;
   }
   return true;
}
