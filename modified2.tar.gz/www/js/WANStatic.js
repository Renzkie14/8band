/*************************
 *      ��ʼ������       *
 *************************/
 function Static_CreateProtocol(){
	var str=Ggeneral_ProtocolStr(mode);
	var addstr=str.ProtocolSelStr+str.NatStr+str.StaticStr+str.IPv4StaticDNSStr+str.GIPv6AddressStr+str.GIPv6PrefixStr+str.GIPv6DNSAdressStr;
	jQuery("#IPv4andIPv6SEL").append(addstr); 
	RouteProtocolSwitch();
	staticIPv4DNSSwitch();
	ipv6AddrSwitch();
	ipv6PDSwitch();
	ipv6DNSAddrSwitch();
 }
 function OnlyForStatic(nowiface){
 		var forDongleStr="";
 		var GMACAddrOverrStr=GMACAddressOverrideStr();
 		if(nowiface.indexOf("USB") > -1){	
			  forDongleStr=onlyForDongle();
		}
		var StaticOptionStr=forDongleStr+GMACAddrOverrStr;
		 jQuery("#DIV_Static").append(StaticOptionStr);
		 setValue("Static_IPv4_DNS_Enable",1);
		 document.getElementById("Static_IPv4_DNS_Enable").disabled=true;
		 staticIPv4DNSSwitch();
 }
 function setStaticdata(obj){
 	
 	}
 function Static_init(){
 		setDisplay("MTUSize",1);
 		setDisplay("DIV_IPv4&6",1);
		setDisplay("DIV_Static",1);
		Static_CreateProtocol();
		OnlyForStatic(iface);
		
		if("edit" == pagecmd){
	  	var WANInfoObj=GWANInfoObj();
	  	setCommendata(WANInfoObj);
	  	setMACAddressOverride(WANInfoObj);
	  	setRouteProtocol(WANInfoObj);
	  	setStaticdata(WANInfoObj);
	  	if(iface.indexOf("USB") > -1){
  		    SetDongle(WANInfoObj);
  	  }
    }
    setLanPort();
 }
 
 /*************************
 *       �ύ����        *
 *************************/
 function StaticSubmit(df,WANindex){
 	 var conn_path="";
   
   if("create" == pagecmd){
	    conn_path="InternetGatewayDevice.WANDevice."+WANindex[0]+".WANConnectionDevice."+WANindex[1]+".WANIPConnection.";
  		AddElements(df, 'add_obj', conn_path);
  	  conn_path+="{i}.";
   }else if("edit" == pagecmd){
   		conn_path=WANPath;
   }else{
   		alert("pagecmd is wrong,pagecmd="+pagecmd);	
   }
   if(!routeProtocol_submit(df,conn_path)){
   		return false;	
   }
   if(!MACAddressOverrideSubmit(df,conn_path)){
   		return false;
   }
   if(!CommonSubmit(df,conn_path,pagecmd)){
   		return false;
   }
	 if(iface.indexOf("USB") > -1){
	 		if(!DongleSubmit(df,conn_path)){
	 				return false;
	 		}
	 }
	 return true;
 }
