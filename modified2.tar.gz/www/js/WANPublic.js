/*****************************
 *   IPv4 and IPv6 ��غ���  *
 *****************************/
function RouteProtocolSwitch(){
	var ProtocolValue=getValue("SELECT_Protocol");
	switch(ProtocolValue){
		case "1":
		  	setDisplay('DIV_IPv6_address',0);
			setDisplay('TR_Nat',1);
			setDisplay('TR_Static_IPv4_DNS_Enable',1);
			if("Static" == mode ){ setDisplay('TR_Static',1)};
		break;
		case "2":
			setDisplay("TR_Nat",0);
			setDisplay('TR_Static_IPv4_DNS_Enable',0);
			if("Static" == mode ){ setDisplay('TR_Static',0)};
			setDisplay('DIV_IPv6_address',1);
		break;
		case "3":
			setDisplay('TR_Nat',1);
			if("Static" == mode ){ setDisplay('TR_Static',1)};
			setDisplay('TR_Static_IPv4_DNS_Enable',1);
			setDisplay('DIV_IPv6_address',1);
		break;	
	}
}
function staticIPv4DNSSwitch(){
	var en=getValue('Static_IPv4_DNS_Enable');
	setDisplay('TR_Static_IPv4_DNS_value',en);
}
function ipv6PDSwitch(){
    /*ҳ���޸ù���
    setDisplay('DIV_IPv6_prefixinfo','Static' == getValue('ipv6PrixRadio') ? 1 : 0);
    */
}
function ipv6DNSAddrSwitch(){
	    setDisplay('DIV_IPv6_DNS_Static', 'Static' == getValue('ipv6DNSAddrRadio')?1:0);
}
function ipv6AddrSwitch(){
    var addrtype = getValue('ipv6AddrRadio');
    setDisplay('DIV_IPv6_Static','Static' == addrtype ? 1 : 0);
    if (addrtype == "Static"){
      setValue('ipv6DNSAddrRadio', 'Static');
      disableCtrl('ipv6DNSAddrRadio', true);  
    }else{
      disableCtrl('ipv6DNSAddrRadio', false);
    }
    ipv6DNSAddrSwitch();
}
function StrObj(){
	this.ProtocolSelStr="";
	this.NatStr="";
	this.StaticStr="";
	this.IPv4StaticDNSStr="";
	this.GIPv6AddressStr="";	
	this.GIPv6PrefixStr="";
	this.GIPv6DNSAdressStr='';
}
function Ggeneral_ProtocolStr(nowMode){
	var Str=new StrObj();
	var protocolSwitchFunStr='onchange="RouteProtocolSwitch()"';
	if("IP_Bridged" == nowMode){
		protocolSwitchFunStr="";	
	}
	if(1){
		Str.ProtocolSelStr='<tr id="ID_TR_ProtocolSelStr">'
			+'<td colspan="2">'
	  			+'<table class="TabTable" cellspacing="0" cellpadding="0">'
				+'<tr>'
				+'<td width="150">'+getStr("LK_IPProtocolTypee")+'</td>'
				+'<td>'
					+'<select id="SELECT_Protocol"'+protocolSwitchFunStr+'>'
							+'<option value="1">IPv4</option>'
							+'<option value="2">IPv6</option>'
							+'<option value="3">IPv4&6</option>'
					+'</select>'
				+'</td>'
				+'</tr>'
				+'</table>'
			+'</td>'
		+'</tr>';	
		Str.NatStr='<tr id="TR_Nat" style="display:none">'
			+'<td colspan="2">'
	  			+'<table class="TabTable" cellspacing="0" cellpadding="0">'
				+'<tr>'
				+'<td width="150">NAT:</td>'
				+'<td><input type="checkbox" id="Nat" checked></td>'
				+'</tr>'
				+'</table>'
			+'</td>'
		+'</tr>';
		Str.StaticStr='<tr id="TR_Static"><td colspan="2">'
	  		+'<table class="TabTable" cellspacing="0" cellpadding="0">'
				+'<tr>'
					+'<td width="150">'+getStr("LK_IPAddresss")+'</td>'
					+'<td><input type="text" id="INPUT_IpAddress" maxlength="15"></td>'
				+'</tr>'
				+'<tr>'
					+'<td>'+getStr("LK_SubnetMaskk")+'</td>'
					+'<td><input type="text" id="INPUT_Mark" maxlength="15"></td>'
				+'</tr>'
				+'<tr>'
					+'<td>'+getStr("LK_DefaultGatewayy")+'</td>'
					+'<td><input type="text" id="INPUT_DefGateway" maxlength="15"></td>'
				+'</tr>'
			+'</table></td></tr>';
		Str.IPv4StaticDNSStr='<tr id="TR_Static_IPv4_DNS_Enable">'
			+'<td colspan="2">'
				+'<table class="TabTable" cellspacing="0" cellpadding="0">'
					+'<tr>'
					+'<td width="150">'+getStr("LK_IPv4StaticDNS")+'</td>'
					+'<td><input type="checkbox" id="Static_IPv4_DNS_Enable" onClick="staticIPv4DNSSwitch()"></td>'
					+'</tr>'
				+'</table>'
			+'</td>'
		+'</tr>'
		+'<tr id="TR_Static_IPv4_DNS_value" style="display:none">'
			+'<td colspan="2">'
	  			+'<table class="TabTable" cellspacing="0" cellpadding="0">'
					+'<tr>'
						+'<td width="150" >'+getStr("LK_PrimaryDNSServer")+'</td>'
						+'<td><input type="text" id="Dns1" maxlength="15"></td>'
					+'</tr>'
					+'<tr>'
						+'<td>'+getStr("LK_SecondaryDNSServer")+'</td>'
						+'<td><input type="text" id="Dns2" maxlength="15"></td>'
					+'</tr>'
				+'</table>'
			+'</td>'
		+'</tr>';
		Str.GIPv6AddressStr='<tr id="DIV_IPv6_address">'
			+'<td colspan="2">'
	  			+'<table class="TabTable" cellspacing="0" cellpadding="0">'
				   +'<tr>'
					+'<td colspan="2">'
						+'<table class="TabTable" cellspacing="0" cellpadding="0">'
							+'<tr>'
							+'<td width="150">'+getStr("LK_GetIPv6Addresss")+'</td>'
			       				+'<td>'
			       					+'<select id="ipv6AddrRadio" onClick="ipv6AddrSwitch()">'
			      					+'<option value="DHCPv6">DHCPv6</option>'
			       					+'<option value="Static">Static</option>'
			       					+'<option value="AutoConfigured">'+getStr("LK_SLAAC")+'</option>'
			       					+'<select>'
	             // +'&nbsp;<input type="radio"  name="ipv6AddrRadio" value="None"  onClick="ipv6AddrSwitch()">Disabled'
							+'</td>'
							+'</tr>'
						+'</table>'
					+'</td>'
				   +'</tr>'
				   +'<tr id="DIV_IPv6_Static">'
					+'<td colspan="2">'
	  					+'<table class="TabTable" cellspacing="0" cellpadding="0">'
							+'<tr>'
							+'<td width="150">'+getStr("LK_IPv6Addresss")+'</td>'
							+'<td><input type="text" id="INPUT_IPv6_IpAddress"  maxlength="80"></td>'
							+'</tr>'
							+'<tr>'
							+'<td width="150">'+getStr("LK_GatewayIPv6Addresss")+'</td>'
							+'<td><input type="text" id="INPUT_IPv6_DefGateway"  maxlength="80"></td>'
							+'</tr>'
						+'</table>'
					+'</td>'
				   +'</tr>';
		Str.GIPv6PrefixStr='<tr id="DIV_IPv6_prefix">'
	  				+'<td colspan="2">'
	  					+'<table class="TabTable" cellspacing="0" cellpadding="0">'
	  						+'<tr>'
	  						+'<td width="150">'+getStr("LK_GetIPv6Prefixx")+'</td>'
	  						+'<td>'
	  							+'<select id="ipv6PrixRadio" onClick="ipv6PDSwitch()">'
	  								+'<option value="PrefixDelegation">PD</option>'
	  								+'<option value="None">Disabled</option>'
	  							+'</select>'
	  						+'</td>'
	  						+'</tr>'
	  					/*  ԭҳ�湦�ܲ�����
	  					+'<tr style="display:none;" id="DIV_IPv6_prefixinfo">'
	  						+'<td width="150">'+getStr("LK_PrefixInfoo")+'</td>'
	  						+'<td><input type="text" id="INPUT_IPv6_Prefix"  maxlength="80"></td>'
	  					+'</tr>'
	  					*/
	  					+'</table>'
	  				+'</td>'
				   +'</tr>';
		Str.GIPv6DNSAdressStr='<tr id="DIV_DNS_address">'	
	  				+'<td colspan="2">'
	  					+'<table class="TabTable" cellspacing="0" cellpadding="0">'
	  						+'<tr>'
								+'<td colspan="2">'
									+'<table class="TabTable" cellspacing="0" cellpadding="0">'
                                                        			+'<tr>'
	  									+'<td width="150">'+getStr("LK_GetDNSs")+'</td>'
	  									+'<td>'
	  										+'<select id="ipv6DNSAddrRadio" onClick="ipv6DNSAddrSwitch()">'
	  											+'<option value="DHCPv6">DHCPv6</option>'
	  											+'<option value="Static">Static</option>'
	  											+'<option value="AutoConfigured">'+getStr("LK_SLAAC")+'</option>'
	  										+'</select>'
	  									
	  									+'</td>'
										+'</tr>'
									+'</table>'
								+'</td>'
	  						+'</tr>'
	  						+'<tr id="DIV_IPv6_DNS_Static">'
	  							+'<td colspan="2">'
	  								+'<table class="TabTable" cellspacing="0" cellpadding="0">'
	  									+'<tr>'
										+'<td width="150">'+getStr("LK_F6DNSs")+'</td>'
										+'<td><input type="text" id="INPUT_IPv6_Dns1"  maxlength="80"></td>'
										+'</tr>'
										+'<tr>'
										+'<td width="150">'+getStr("LK_S6DNSs")+'</td>'
										+'<td><input type="text" id="INPUT_IPv6_Dns2"  maxlength="80"></td>'
										+'</tr>'
	  								+'</table>'
	  							+'</td>'
	  						+'</tr>'
	  					+'</table>'
	  				+'</td>'
	  			   +'</tr>'
				+'<table>'
			+'</td></tr>';
	}
	return 	Str;
}
function routeProtocol_submit(df,conn_path){
	  var service_type = getValue('ServiceType');
    var IPmode=getValue('SELECT_Protocol');
		if(2 != IPmode){                      //ipv4 and ipv4_ipv6
			AddElements(df, conn_path + 'NATEnabled', getValue('Nat'));
			var static_dns_enable = getValue('Static_IPv4_DNS_Enable');
		  var dns = getValue('Dns1') + ',' + getValue('Dns2');
		  dns = dns.replace(/(^,*)|(,*$)/g,'');
		  if('1' == static_dns_enable){
				 if(!isCheckIPV4($('Dns1'))){            
			      return false;
			   }
			   if(getValue('Dns2') !="" && !isCheckIPV4($('Dns2'))){    
				    return false;
			   }
			   AddElements(df, conn_path + 'DNSServers', dns);
		  }
		  AddElements(df, conn_path + 'DNSOverrideAllowed', static_dns_enable);
		  if("Static" == mode || "IPoA" == mode){
		  		if(!isCheckIPV4($('INPUT_IpAddress'))){            
              return false;
          }
          if(!isCheckIPV4($('INPUT_Mark'),0,255)){            
              return false;
          }
          if(!isCheckIPV4($('INPUT_DefGateway'))){            
              return false;
          }
					if(getValue('INPUT_IpAddress') == getValue('INPUT_DefGateway')){
              top.AlertMsg(getStr("LK_sameipwarning"));
              return false;
          }
          AddElements(df, conn_path + 'ExternalIPAddress', getValue('INPUT_IpAddress'));
          AddElements(df, conn_path + 'SubnetMask', getValue('INPUT_Mark'));
          AddElements(df, conn_path + 'DefaultGateway', getValue('INPUT_DefGateway'));
		  }
    }
    if(1 != IPmode){               //ipv6 and ipv4_ipv6	
   		 var ipv6AddrType = getValue('ipv6AddrRadio');
       var ipv6DNSAddrType = getValue('ipv6DNSAddrRadio');
       /* DHCPv6, Static, RA(SLAAC) */
       AddElements(df, conn_path + 'X_CT-COM_IPv6IPAddressOrigin', ipv6AddrType);
	     if ('Static' == ipv6AddrType){
	     		if (!checkStaticIPv6()) {
            return false;
          }
	        var ipv6Addr_Prefix = getValue('INPUT_IPv6_IpAddress');
	        var addrPrefix = ipv6Addr_Prefix.split('/');    	        
	        AddElements(df, conn_path + 'X_CT-COM_IPv6IPAddress', addrPrefix[0]);
	        AddElements(df, conn_path + 'X_CT-COM_IPv6AddressPrefixLen', addrPrefix.length == 2 ? addrPrefix[1] : '128');
	        AddElements(df, conn_path + 'X_CT-COM_DefaultIPv6Gateway', getValue('INPUT_IPv6_DefGateway'));
	     }else{
	     		AddElements(df, conn_path + 'X_CT-COM_IPv6AddressPrefixLen','');
	     }
	     
	     if('Static' == ipv6DNSAddrType){
	     		if (!checkStaticIPv6DNS()) {
            return false;
          }
	        var ipv6Dns = getValue('INPUT_IPv6_Dns1') + ',' + getValue('INPUT_IPv6_Dns2');
	        ipv6Dns = ipv6Dns.replace(/(^,*)|(,*$)/g,'');
	         /* delete the first and last comma */
	        AddElements(df, conn_path + 'X_CT-COM_IPv6DNSServers', ipv6Dns); 
	     }   
	     AddElements(df,conn_path+'X_CT-COM_IPv6DNSAddressSource',ipv6DNSAddrType); 
	     
	    /* set pd to disable when tr069 */
	    var prix_type = getValue('ipv6PrixRadio');
	    AddElements(df, conn_path + 'X_CT-COM_IPv6PrefixOrigin', prix_type);  
	    if (service_type == 'TR069' || service_type == 'OTHER'){
	        AddElements(df, conn_path + 'X_CT-COM_IPv6PrefixDelegationEnabled', '0');
	    }else{
	        AddElements(df, conn_path + 'X_CT-COM_IPv6PrefixDelegationEnabled','PrefixDelegation' == prix_type ? '1':'0');
	    }
	    /* ԭҳ�湦�ܲ�����       
	    if (prix_type == 'Static'){
	        AddElements(df, conn_path + 'X_CT-COM_IPv6Prefix', getValue('INPUT_IPv6_Prefix'));
	        AddElements(df, conn_path + 'X_CT-COM_IPv6PrefixPltime', '7200');
	        AddElements(df, conn_path + 'X_CT-COM_IPv6PrefixVltime', '172800');
	    }*/
    }	
    return true;
}
function setRouteProtocol(obj){
	
	setValue('SELECT_Protocol',obj.IPMode);
	setValue('Nat',obj.NATEnabled);
	setValue('Static_IPv4_DNS_Enable',obj.DNSOverrideAllowed);
	if('1' == obj.DNSOverrideAllowed){
		var DNSServer =obj.DNSServers.split(',');
	  setValue('Dns1', DNSServer[0]);
	  setValue('Dns2', DNSServer[1] == undefined ? '' : DNSServer[1]);
  }
  
  setValue('ipv6AddrRadio',obj.IPv6IPAddressOrigin);
  setValue('INPUT_IPv6_IpAddress',obj.IPv6IPAddress + "/" +obj.IPv6AddressPrefixLen);
  setValue('INPUT_IPv6_DefGateway',obj.DefaultIPv6Gateway);
  
  if(obj.IPv6PrefixDelegationEnabled == "1"){
     setValue('ipv6PrixRadio', "PrefixDelegation");
  }else{
     setValue('ipv6PrixRadio', "None");
  }
  
  setValue('ipv6DNSAddrRadio',obj.IPv6DNSType);
  var IPv6DNSServer = obj.IPv6DNSServers.split(',');
  setValue('INPUT_IPv6_Dns1', IPv6DNSServer[0]);
  setValue('INPUT_IPv6_Dns2', IPv6DNSServer[1] == undefined ? '' : IPv6DNSServer[1]);
  
  if("Static" == mode || "IPoA" == mode){
  	setValue('INPUT_IpAddress', obj.ExternalIPAddress);
    setValue('INPUT_Mark',obj.SubnetMask);
    setValue('INPUT_DefGateway',obj.DefaultGateway);	
  }
  RouteProtocolSwitch();
  staticIPv4DNSSwitch();
	ipv6AddrSwitch();
	ipv6PDSwitch();
	ipv6DNSAddrSwitch();
}
/************************************
 *        MACAddressOverride        *
 ************************************/
function MACAddressOverrideEnable(){
    setDisplay('DIV_MACAddress', getValue('INPUT_MACAddressOverrideEnable'));
}
function cloneMac(){
    setValue('INPUT_MACAddress', macUsed);
}
function GMACAddressOverrideStr(){
var MACAddressStr="";
 	if(1){
 		MACAddressStr='<table id="DIV_MAC_Setting" class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0">' 
				+'<tr>' 
					+'<td width="150">'+getStr("LK_EnableMACAddressOverride")+'</td>' 
					+'<td>' 
						+'<input type="checkbox" id="INPUT_MACAddressOverrideEnable" onClick="MACAddressOverrideEnable()">' 
					+'</td>' 
				+'</tr>' 
				+'<tr id="DIV_MACAddress" style="display:none">' 
					+'<td width="150">'+getStr("LK_MACCloneAddress")+'</td>' 
					+'<td>' 
						+'<input type="text" id="INPUT_MACAddress">' 
						+'<input type="button"  onclick="cloneMac()" value="'+getStr("LK_MACClone")+'">' 
					+'</td>' 
				+'</tr>' 
			+'</table>';	
 	}
 	return MACAddressStr;
}
function MACAddressOverrideSubmit(df,conn_path){
   AddElements(df, conn_path + 'MACAddressOverride', getValue('INPUT_MACAddressOverrideEnable'));
   AddElements(df, conn_path + 'MACAddress', getValue('INPUT_MACAddress'));
   return true;
} 
function setMACAddressOverride(obj){
	setValue('INPUT_MACAddressOverrideEnable',obj.MACAddressOverride);
	setValue('INPUT_MACAddress',obj.MACAddress);
	MACAddressOverrideEnable();
}
/************************************
 *              Dongle              *
 ************************************/
function onlyForDongle(){
 var forDongleStr='<table class="ContentTableNoColor" cellspacing="0" width="600" cellpadding="0" >'
				      +'<tr id="PIN">'
				      	+'<td width="150">'+getStr("LK_PIN")+'</td>'
					      +'<td><input type="text" id="INPUT_PIN"></td>'
				      +'</tr>'
							+'<tr id="APN">'
								+'<td >'+getStr("LK_APN")+'</td>'
								+'<td><input type="text" id="INPUT_APN"></td>'
							+'</tr>'
							+'<tr id="Dial_Number">'
								+'<td>'+getStr("LK_DN")+'</td>'
								+'<td><input type="text" id="INPUT_DN"></td>'
							+'</tr>'
				   +'</table>';
	return forDongleStr;
}
function DongleSubmit(df,conn_path){	
      AddElements(df, conn_path + 'X_TRI_APN', getValue('INPUT_APN'));
      AddElements(df, conn_path + 'X_TRI_PIN', getValue('INPUT_PIN'));
      AddElements(df, conn_path + 'X_TRI_DialNumber', getValue('INPUT_DN'));   
      return true;	
}
function SetDongle(obj){
	setValue("INPUT_APN",obj.X_TRI_APN);
	setValue("INPUT_PIN",obj.X_TRI_PIN);
	setValue("INPUT_DN",obj.X_TRI_DialNumber);
}
/************************************
 *              vlan                *
 ************************************/
function vlan_process(df, wanc_instance_path, multicastvlan){
    var vlan_id=(0 == getValue('VlanEnable') ? "-1" : getValue('VlanId')); 
    vlan_keeptag = getValue('VlanPassKeepTagEnable');
           
    AddElements(df, wanc_instance_path + 'X_TRI_VlanID', vlan_id); 
    AddElements(df, wanc_instance_path + 'X_TRI_VlanPassKeepTag', vlan_keeptag);
    if (multicastvlan != -1 && vlan_id == multicastvlan){
        top.AlertMsg("Public Multicast VLAN ID is " + multicastvlan + ",wan connection VLAN ID must not be the same value.");
        return false;
    }
    if(vlan_id != '-1'){
      AddElements(df, wanc_instance_path + 'X_TRI_VlanPriority', getValue('SELECT_802.1p'));
			var vlanTaggingIf = "";
			for(var i = 0; i < 4; i++){
				if('1' == getValue('VlanTagPort' + i)){
					vlanTaggingIf +=  gLanArray[i].path + ",";
				}
	    }
			AddElements(df, wanc_instance_path + 'X_TRI_VlanTaggingIf', vlanTaggingIf.replace(/(^,*)|(,*$)/g,''));
    } else{
      AddElements(df, wanc_instance_path + 'X_TRI_VlanTaggingIf', '');
    }
    return true;
}
/************************************
 *          BindingPorts            *
 ************************************/
function getBindingports(){
    /* the selected lan port and ssid */
    var binding_ports = '';
    var service_type = getValue('ServiceType');	  
    /* �����TR069����VOIP������Ҫ�˿ڰ󶨣����ؿ� */
	  /* Con-Bridge Voip ��Ҫ�˿ڰ�, 2016/07/21 */
    if(('TR069' == service_type && 'Con_Bridged' != mode) || ( 'VOIP'== service_type && 'Con_Bridged' != mode) ||('TR069,VOIP' == service_type) ){
        return "";
    }
    //LAN
    for (var i = 1; i < 5; i++){
        if ($('LanPort' + i) && getValue('LanPort' + i) == 1){
            
            binding_ports += 'InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.' + (getIndexByDescription("LAN"+i)+1) + ',';
        }
    }
    //SSID
    for (var i = 1; i < 9; i++){
        if ($('WlanSsid' + i) && getValue('WlanSsid' + i) == 1){
            binding_ports += 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.' + i + ',';
        }
    }
    /* delete the first and last comma */
    binding_ports = binding_ports.replace(/(^,*)|(,*$)/g,'');
    return binding_ports;
}
/************************************
 *             Common               *
 ************************************/
function getIndexByDescription(Description){
    var i;

    for(i=0;i<gLanArray.length;i++)
    {
        if(gLanArray[i].description == Description)
           return i;
    }
}
function GWANInfoObj(){
	 for(var i=0;i<WanConnDevs.length;i++){
	 	for(var j=0;j<WanConnDevs[i].conns.length;j++){
	 		if(WanConnDevs[i].conns[j].Path == WANPath){
	 			return WanConnDevs[i].conns[j];
	 		}
	 	}	
	 }
	alert("no this wanpath:"+WANPath);
	return false;
}
function setVlanTagging(obj){
	// Firstly, set all the checkbox to non-checked,
	for(var i = 0; i < gLanArray.length; i++){
		setValue('VlanTagPort' + i, '0');
	}
	for(var i = 0; i < gLanArray.length; i++)
	{
		var VlanNum = getIndexByDescription("LAN"+(i+1));
		setValue('VlanTagPort' + i, obj.VLANTaggingIf.indexOf('LANEthernetInterfaceConfig.' + (VlanNum+1)) > -1 ? 1 : 0);
  }
}
function setPortBind(obj){
 /* port binding */
    setValue('LanPort1',obj.LanInterface.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN1")+1)) > -1 ? 1 : 0);
    setValue('LanPort2',obj.LanInterface.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN2")+1)) > -1 ? 1 : 0);
    setValue('LanPort3',obj.LanInterface.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN3")+1)) > -1 ? 1 : 0);
    setValue('LanPort4',obj.LanInterface.indexOf('LANEthernetInterfaceConfig.'+(getIndexByDescription("LAN4")+1)) > -1 ? 1 : 0);

    setValue('WlanSsid1',obj.LanInterface.indexOf('WLANConfiguration.1') > -1 ? 1 : 0);
    setValue('WlanSsid2',obj.LanInterface.indexOf('WLANConfiguration.2') > -1 ? 1 : 0);
    setValue('WlanSsid3',obj.LanInterface.indexOf('WLANConfiguration.3') > -1 ? 1 : 0);
    setValue('WlanSsid4',obj.LanInterface.indexOf('WLANConfiguration.4') > -1 ? 1 : 0);
    setValue('WlanSsid5',obj.LanInterface.indexOf('WLANConfiguration.5') > -1 ? 1 : 0);
    setValue('WlanSsid6',obj.LanInterface.indexOf('WLANConfiguration.6') > -1 ? 1 : 0);
    setValue('WlanSsid7',obj.LanInterface.indexOf('WLANConfiguration.7') > -1 ? 1 : 0);
    setValue('WlanSsid8',obj.LanInterface.indexOf('WLANConfiguration.8') > -1 ? 1 : 0);
}
function setLanPort(){
    var used_node = new Array();
    var PortNum;
    var Nu=0;
    if(NumOfWLAN > 4)
    {
    	 setDisplay('DIV_WLAN_EXT',true);
    }
    else if(NumOfWLAN > 0)
    {
    	 setDisplay('DIV_WLAN_EXT',false);
    }
    else
    {
       setDisplay('DIV_WLAN_EXT',false);
       setDisplay('DIV_WLAN',false);
    }
  
    //�ѱ�ʹ�õ�LAN�˿ڱ��浽�����У������ĳ���
    for(var i=0;i<WanConnDevs.length;i++){
    	for(var j=0;j<WanConnDevs[i].conns.length;j++){
	     	if(WanConnDevs[i].conns[j].Path == WANPath){
	    		continue;
	    	}
	    	
	    	if(((iface.indexOf("ATM") > -1) && (WanConnDevs[i].ptmEnable == 1)) ||
	    	   ((iface.indexOf("PTM") > -1) && (WanConnDevs[i].DslEnable == 1))){
	    	   	continue;
	    	}
	    	
    		var used_lanport=WanConnDevs[i].conns[j].LanInterface.split(',');
    	  for(var k = 0; k < used_lanport.length;k++){
    			if(used_lanport[k].indexOf('LANEthernetInterfaceConfig') >= 0){
    				PortNum = getIndexByDescription("LAN"+ used_lanport[k].substr(used_lanport[k].length - 1, 1))+1; 
    				used_node[Nu]= 'LanPort' + PortNum;
    				Nu++;
    			}else if(used_lanport[k].indexOf('WLANConfiguration') >= 0){
            used_node[Nu]= 'WlanSsid' + used_lanport[k].substr(used_lanport[k].length - 1, 1);  
            Nu++;                   
          }	
    		} 
    	}	
    }
    for(var i=0;i<used_node.length;i++){
    	disableCtrl(used_node[i],true);
    } 
   
}
function setCommendata(obj){
		setValue('ConnectionName',obj.Name);
		setValue('WANEnable',obj.Enable);
		setValue('MTU',obj.MaxMTUSize);
	  setValue('VlanPassKeepTagEnable',obj.VLANPass);
		setValue('VlanEnable',(-1 != obj.VLANID?1:0));
		setValue('VlanId',(-1 != obj.VLANID?obj.VLANID:""));
    setValue('SELECT_802.1p',obj.VLANPriority);
    setValue('ServiceType',obj.ServiceList);
    setValue('ID_TD_Transparent',obj.DhcpTransparent == '1' ? 1 : 0);
    setVlanTagging(obj);
    setPortBind(obj);
		VlanEnableChange();
    ServiceTypeSwitch();
}
function CommonSubmit(df, conn_path,pagecmd){
	 var service_type = getValue('ServiceType');
	 var checkFlag=0;
	 var IPmode = getValue("SELECT_Protocol");

	 if(!validateCode()){
        return false;
   }
	 if(!checkWanName(pagecmd)){
		 return false;
	 }
	 if(!checkPortBinding()){
   		return false;	
   }
   if(!checkVLAN()){
   	  return false;	
   }   
	 AddElements(df, conn_path + 'Name',getValue('ConnectionName'));
   AddElements(df, conn_path + 'Enable',getValue('WANEnable'));

   if("Con_Bridged" == mode){
	   	AddElements(df, conn_path + 'X_CT-COM_IPMode','1');
   }else{
   		AddElements(df, conn_path + 'X_CT-COM_IPMode', IPmode);
   }
   if(mode.indexOf("Bridged") > -1){
      AddElements(df, conn_path + 'ConnectionType', mode);
      AddElements(df, conn_path + 'MaxMTUSize', "1492");
	 }else{
		 	if (!checkMTU(IPmode)){
	        return false
	    }
		 	AddElements(df, conn_path + 'ConnectionType',"IP_Routed");
		 	AddElements(df, conn_path + 'MaxMTUSize', getValue('MTU'));
	 }
	 if(-1 == mode.indexOf("PPP")){
	    if("IPoA" == mode || "Static" == mode){
	    	 AddElements(df, conn_path + 'AddressingType', 'Static');
	    }else{
	      AddElements(df, conn_path + 'AddressingType', 'DHCP');
	    }
	 }
   if(service_type == 'INTERNET'){
     $('ID_TD_Transparent').checked==true?checkFlag=1:checkFlag=0;
     AddElements(df, conn_path+"X_TRI_DhcpTransparent",checkFlag);
   }
   AddElements(df, conn_path + 'X_CT-COM_ServiceList',service_type);// ����ģʽ 
   AddElements(df, conn_path + 'X_CT-COM_LanInterface',getBindingports());// �˿ڰ� 
   if (false == vlan_process(df,conn_path,-1)){
    	return false;
   }
   return true;
}
/************************************
 *             PPP WAN              *
 ************************************/
var password_changed=0;
function Password_changed(){
    password_changed=1;
    return true;
}
function LimitRetryTimeEnable(){
    var LimitEnable = getValue('INPUT_LimitRetryTimeEnable');
    setDisplay('DIV_RetryTime', LimitEnable)
}
/************************************
 *         check function           *
 ************************************/
function isValidStr(str){
	var unsafestr="\\\'";
    var i = 0;
    for (i = 0; i < str.length; i++){
        if(unsafestr.indexOf(str.charAt(i)) != -1){
            return false;
        }
    }
    return true;
}
function checkWanName(pagecmd){
	var lk_str="";
	var Name=getValue('ConnectionName');
	if(""==Name){
		lk_str = 'LK_null';
		top.AlertMsg(getStr(lk_str),'ConnectionName');
		return false;
	}else{
		for(var i=0;i<WanConnDevs.length;i++){
			for(var j=0;j<WanConnDevs[i].conns.length;j++){
				if(Name == WanConnDevs[i].conns[j].Name && "create" == pagecmd){
						lk_str = "LK_repeat";
						top.AlertMsg(getStr(lk_str),'ConnectionName');
						return false;
				}
		  }
		}		
	}
	return true;
}
function checkMTU(IPmode){
    var MTU = getValue('MTU');
	var mtuMin=576;
	var msg="";
	
	if(IPmode>1)
		mtuMin=1280;

    if (mode == 'IP_Bridged' || (mode != 'PPPoE' && mode != 'PPPoA')){
        /* bridge or ip connection */
        if (MTU < mtuMin || MTU > 1500){
			if(IPmode>1)
				msg=getStr("LK_TheV6Range1500");
			else
				msg=getStr("LK_TheRange1500");

			top.AlertMsg(msg,"MTU");
            return false;
        }
    }else{
        /* pppoe connection */
        if (MTU < mtuMin || MTU > 1492){
			if(IPmode>1)
				msg=getStr("LK_TheV6Range1492");
			else
				msg=getStr("LK_TheRange1492");

			top.AlertMsg(msg,"MTU");
            return false;
        }
    }
    return true;
}
function checkVLAN(){
  var targetVlan = getValue("VlanId");

  if (getValue('VlanEnable') == 0) {
      return true;
  }else{
		if(targetVlan == ""){
			top.AlertMsg(getStr('LK_InputVlanID'),"VlanId");
			return false;
		}else if(isAllNum(targetVlan)==0){
			top.AlertMsg(getStr('LK_InputNum'),"VlanId");
			return false;
		} else{
		  if(targetVlan < 1 || targetVlan > 4094){
		    top.AlertMsg(getStr("LK_vlaniderror"),"VlanId");
		    return false;
		  }
	  }
	}
  return true;
}
function checkPortBinding(){
	var service_type = getValue('ServiceType');
	if(((service_type == 'INTERNET') && (mode == 'IP_Bridged') && ($('ID_TD_Transparent').checked==true))
		&& ((getBindingports() == ''))){
		top.AlertMsg("Please select bonding port.");
		return false; 
	}
    return true;
}
function checkStaticIPv6() {
    var name=getValue('INPUT_IPv6_IpAddress').indexOf("/");
    if (name == -1) {
        if(!isIPv6Valid($('INPUT_IPv6_IpAddress'))){            
            return false;
        }
    }else{
        var ipv6Addr=getValue('INPUT_IPv6_IpAddress').split("/");
        if(!isIPv6AddrValid(ipv6Addr[0])){            
            return false;
        }
        if (ipv6Addr[1] < 0 || ipv6Addr[1] > 128 || isAllNum(ipv6Addr[1]) == 0 ) {
           top.AlertMsg(getStr("LK_ip6prefix"),"INPUT_IPv6_IpAddress");
           return false;
       }
    }
    if(!isIPv6Valid($('INPUT_IPv6_DefGateway'))){            
        return false;
    }
    return true;
}
function checkStaticIPv6DNS() {
	var ipv6DNSAddrRadio = getValue('ipv6DNSAddrRadio');
	if(ipv6DNSAddrRadio == 'Static'){
	    if(!isIPv6Valid($('INPUT_IPv6_Dns1'))){            
	         return false;
	    }
	    if(getValue('INPUT_IPv6_Dns2') !=""){
	        if(!isIPv6Valid($('INPUT_IPv6_Dns2'))){            
	            return false;
	        }
	    }
	}
    return true;
}
