function printBeginContent()
{
	document.write('<table width="100%" class="MainContent"><tr><td>');
}

function printEndContent()
{
	document.write('</td></tr></table>');
}
function printApply(Func)
{
	document.write('<table style="margin-top:30;"><tr><td><img src="../../skin/_blank.gif" width="15">');
	PrintTriButton("Save",LK_Save,Func);
	document.write('</td></tr></table>');
}
function PageBack(a)
{
	document.location = a;
}
function SetContentTitle(value ,Name)
{
	if(Name)
		document.write('<table id="'+Name+'" class="TitleStyle">');
	else	
		document.write('<table class="TitleStyle">');
	document.write('<tr><td>');
	document.write(value);
	document.write('</td></tr>');
	document.write('</table>');
}
function printTriText(Name,MaxLength,Size)
{
	document.write('<input type="text" name="'+Name+'" id="'+Name+'" size="'+Size+'" maxlength="'+MaxLength+'">');
}
function printTriPassword(Name,MaxLength,Size)
{
	document.write('<input type="Password" name="'+Name+'" id="'+Name+'" size="'+Size+'" maxlength="'+MaxLength+'">');
}
function PrintTriButton(Name,Value,Fun)
{
	document.write('<input type="button" onmouseover="ChangeButtonStyle(this,\'mouseover\');" onmouseout="ChangeButtonStyle(this,\'mouseout\');" class="Tributton" id="'+Name+'" name="'+Name+'" onClick="'+Fun+'" value="'+Value+'" >');
}
function PrintTriSubmitButton(Name,Value,Fun)
{
	document.write('<input type="submit" onmouseover="ChangeButtonStyle(this,\'mouseover\');" onmouseout="ChangeButtonStyle(this,\'mouseout\');" class="Tributton" id="'+Name+'" name="'+Name+'" onClick="'+Fun+'" value="'+Value+'" >');
}
function printTriCheckBox(Name,Func)
{
	document.write('<input type="checkbox" id="'+Name+'" name="'+Name+'" onClick="'+Func+'">');
}
function ChangeButtonStyle(obj, EventType, haspath)
{
	if(EventType == 'mouseover')
	{
		obj.className = "Tributton Hover";
	}
	else if(EventType == 'mouseout')
	{
		obj.className = "Tributton";
	}
}	
function uiPageRefresh()
{
	document.location.reload();
}
function SetButtonStatus(Name, StatusType)
{
	var obj = document.getElementById(Name);
	if(StatusType == 'disabled')
	{
		obj.disabled = true;
		obj.className = "Tributton Disable";
		obj.style.visibility = "visible";
		obj.style.cursor = "default";
	}
	else
	{
		obj.disabled = false;
		obj.style.visibility = "visible";
		obj.style.cursor = "pointer";
		obj.className = "Tributton";
	}
}
/*
验证码定制方法：
在project.js中添加一下代码
function project_init(tag_name)
{
    switch(tag_name){
    case "basic_WANServiceInfo.shtml":
    case "mngt_fwupgrading.shtml":
    case "adv_dynamicroute.shtml":
    case "adv_v6staticroute.shtml":
    case "adv_ipgre.shtml":
        break;
    case "login.html":
            createValidateForLogin();
        break;
    default:
        var tag_menu = tag_name.substr(0,6);
        if("status" != tag_menu)
            createValidateBlock();
        break;
    }
    return;

}
*/
/*清楚验证码输入框的值，并更新验证码*/
function clearValidateBlock()
{
    document.getElementById("INPUT_CAPTCHA1").value = "";
    createCode();
}
var checkId;
/*创建验证码输入框，产生验证码*/
function createValidateBlock()
{
	var codeNum = jQuery("tr[id^='BUTTON_BLOCK']").length;
	for (var i = 1; i <= codeNum; i++ )
	{
		var ValidateBlock =	'<tr>'
							+ '<td width="150">'+getStr("LK_Validate_code")+'</td>'
							+ '<td>'
							+ '<input type="text" id="INPUT_CAPTCHA' + i + '" />&nbsp;&nbsp;'
							+ '<input type="text" unselectable="on" onselectstart="return false;" onclick="createCode(this.id)" onfocus="this.blur()" readonly="readonly" id="checkCAPTCHA' + i + '" class="unchanged" style="width: 85px; height: 27px; font-weight:900;text-align:center;cursor: default;background:url('+'/skin/yawp.jpg'+');" />'
							+ '</td>'
							+ '</tr>';

		var block_id = "#BUTTON_BLOCK";
		if(i > 1)
			block_id += i;
		jQuery(block_id).before(ValidateBlock);
	}
    createCode();
}
/*为login页面创建验证码输入框，产生验证码*/
function createValidateForLogin()
{
     var ValidateBlock = '<tr height="6">'
                         +'<tr>'
                            +'<td id="ID_Td_Login_captcha" style="font:14px Arial;color:#fff"></td>'	
                            +'<td><input type="text" id="INPUT_CAPTCHA1" style="height:22px; width:180px;font-family:Arial;" /><td>'
                         +'</tr>'
                         +'<tr height="6">'
                         +'<tr>'
                            +'<td></td>'
                            +'<td>'
                                +'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                                +'<input type="text" unselectable="on" onselectstart="return false;" onclick="createCode(this.id)" onfocus="this.blur()" readonly="readonly" id="checkCAPTCHA1" class="unchanged" style="width: 85px; height: 27px; font-weight:900;text-align:center;cursor: default;background:url('+'/skin/yawp.jpg'+');" />'
                            +'</td>'
                         +'</tr>';
    jQuery("#BUTTON_BLOCK").before(ValidateBlock);
     createCode();
}
/*产生验证码*/
function createCode() 
{ 
	var codeNum = jQuery("tr[id^='BUTTON_BLOCK']").length;
	var id;
	var codeLength = 5; //the length of the captcha code
	var checkCode;
    /*验证码中的0,1用9,8代替，O,I用P,H代替*/
	var selectChar = new Array(9,8,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','H','J','K','L','M','N','P','P','Q','R','S','T','U','V','W','X','Y','Z');
	if(arguments.length > 0)
	{
		id = arguments[0];
		checkCode = document.getElementById(id);
		checkId = id;
	}

	for(var num = 1; num <= codeNum; num++)
	{
		if(arguments.length == 0)
			checkCode = document.getElementById("checkCAPTCHA" + num);
		else
		{
			checkCode = document.getElementById(id);
			num = codeNum;
		}

		var code = "";
		for(var i=0; i < codeLength; i++) 
		{
			var charIndex = Math.floor(Math.random()*36); 
			code +=selectChar[charIndex];
		} 
		if(checkCode) 
		{ 
			checkCode.className="code"; 
			checkCode.value = code; 
		}
	}
}
/*对验证码进行校验*/
function validateCode()
{
	var inputCode;
	var code;
    var captcha1obj = document.getElementById("INPUT_CAPTCHA1");
    if(!captcha1obj || "undefined" == captcha1obj)
        return true;
	if(arguments.length == 0)
	{
		inputCode = document.getElementById("INPUT_CAPTCHA1").value;
		code = document.getElementById("checkCAPTCHA1").value;
		checkId = "checkCAPTCHA1"
	}
	else if(arguments.length == 1)
	{
		inputCode = document.getElementById("INPUT_CAPTCHA" + arguments[0]).value;
		code = document.getElementById("checkCAPTCHA" + arguments[0]).value;
		checkId = "checkCAPTCHA" + arguments[0];
	}

	if(inputCode.length <=0)
	{
		top.AlertMsg(getStr("LK_Validate_code_null_Err"));
        clearValidateBlock();
		return false;
	}
	else if(inputCode.toLowerCase() != code.toLowerCase())
	{
		top.AlertMsg(getStr("LK_Validate_code_Err"));
        clearValidateBlock();
		return false;
	}
    clearValidateBlock();
	return true;
}
/*对login页面的验证码进行校验*/
function validateCodeForLogin()
{
    var inputCode;
	var code;
    var captcha1obj = document.getElementById("INPUT_CAPTCHA1");
    if(!captcha1obj || "undefined" == captcha1obj)
        return true;
	if(arguments.length == 0)
	{
		inputCode = document.getElementById("INPUT_CAPTCHA1").value;
		code = document.getElementById("checkCAPTCHA1").value;
		checkId = "checkCAPTCHA1"
	}
	else if(arguments.length == 1)
	{
		inputCode = document.getElementById("INPUT_CAPTCHA" + arguments[0]).value;
		code = document.getElementById("checkCAPTCHA" + arguments[0]).value;
		checkId = "checkCAPTCHA" + arguments[0];
	}

	if(inputCode.length <=0)
	{
		jQuery("#ErrorTd").html(getLogStr("LK_Validate_code_null_Err"));
        clearValidateBlock();
		return false;
	}
	else if(inputCode.toLowerCase() != code.toLowerCase())
	{
		jQuery("#ErrorTd").html(getLogStr("LK_Validate_code_Err"));
        clearValidateBlock();
		return false;
	}
    clearValidateBlock();
	return true;
}
function SetTitle(title_str){
	document.title = title_str;
}
function SetCopyright(str){
    if(str.length == 0)
        document.getElementById('ID_Copyright').innerHTML = '';
    else
        document.getElementById('ID_Copyright').innerHTML = 'Copyright © ' + str + ' Technology Co.,LTD. 2022. All Rights Reserved.';
}
